/**
 * @class
 * @property {number} id - 
 * @property {number} organizationId - 
 */
class SuperkodaEntity {
  constructor() {
    /** @type {number} */ this.id = null;
    /** @type {number} */ this.organizationId = null;
  }
}

/**
 * @class
 * @template T
 */
class ScopedSecureRepository {
  /** @returns {T[]} */ findAll() {}
  /** @param {Object} idOrSpecification @returns {T} */ findOne(idOrSpecification) {}
  /** @param {string} fieldName @param {Object} value @returns {T[]} */ search(fieldName, value) {}
  /** @param {string} propertyName @param {Object} value @returns {T[]} */ searchByProperty(propertyName, value) {}
  /** @param {T} entity @returns {T} */ saveOne(entity) {}
  /** @param {Object} entitiesCollection @returns {T[]} */ saveAll(entitiesCollection) {}
  /** @param {Object} idOrEntity @returns {boolean} */ deleteOne(idOrEntity) {}
  /** @returns {number} */ count() {}
  /** @param {Object} idOrEntity @returns {boolean} */ existsOne(idOrEntity) {}
  /** @returns {T} */ getNew() {}
  /** @returns {{[key: string]: string}} */ asDatalistCollection() {}
  /** @param {string} keyField @param {string} labelField @returns {{[key: string]: string}} */ asDatalistCollectionFields(keyField, labelField) {}
  /** Bind submitted values (a.web.requestParameters or {field: value}) to a new record, or onto [record], by the entity's rules; not saved. @param {Object} values @param {T} [record] @returns {BindResult} */ bind(values, record) {}
  /** The entity's rules over a record, without saving: {field: messageKey}, empty when valid. @param {T} record @returns {{[field: string]: string}} */ validate(record) {}
  /** @param {string} field @param {function(*, *, *): *} [where] @returns {number} */ sum(field, where) {}
  /** @param {string} field @param {function(*, *, *): *} [where] @returns {number} */ avg(field, where) {}
  /** @param {string} field @param {function(*, *, *): *} [where] @returns {*} */ min(field, where) {}
  /** @param {string} field @param {function(*, *, *): *} [where] @returns {*} */ max(field, where) {}
  /** Grouped aggregates: {groupBy: ['category'], sum: ['amount'], count: true, where, orderBy: 'sum_amount desc', limit: 10} → [{category, sum_amount, count}]. @param {{groupBy?: (string|string[]), sum?: (string|string[]), avg?: (string|string[]), min?: (string|string[]), max?: (string|string[]), count?: boolean, where?: function(*, *, *): *, orderBy?: (string|string[]), limit?: number}} options @returns {Object[]} */ aggregate(options) {}
  /** One field's values, in id order. @param {string} field @param {function(*, *, *): *} [where] @returns {Array} */ pluck(field, where) {}
  /** The named fields of each row, in id order. @param {string[]} fields @param {function(*, *, *): *} [where] @returns {Object[]} */ select(fields, where) {}
  /** Set values on every row where selects and save each (write check, rules, audit, events) in one transaction; returns how many. @param {function(*, *, *): *} where @param {Object} values @returns {number} */ updateAll(where, values) {}
}

/**
 * @class
 */
class BindResult {
  /** @returns {boolean} */ isValid() {}
  /** Message keys by field; '' for the record as a whole. @returns {{[field: string]: string}} */ getErrors() {}
  /** @param {string} field @returns {string} */ getError(field) {}
  /** The record: with the values when valid, untouched otherwise. @returns {*} */ getRecord() {}
  /** The values as submitted, to show the form again. @returns {Object} */ getValues() {}
}

/**
 * @readonly
 * @enum {string}
 */
const SecurityScope = {
   ALL: 'ALL',
   GLOBAL: 'GLOBAL',
   ORGANIZATION: 'ORGANIZATION',
   USER: 'USER',
   USER_IN_ORGANIZATION: 'USER_IN_ORGANIZATION',
 }

/**
 * @class
 */
class ResponseFactory {
  constructor() {
  }

  /**
   *  
   *
   * @param {InputStream} content - parameter
   * @param {string} contentType - parameter
   * @returns {Response}
   */
  stream(content, contentType) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {InputStream} content - parameter
   * @param {string} filename - parameter
   * @param {string} contentType - parameter
   * @returns {Response}
   */
  file(content, filename, contentType) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {number[]} content - parameter
   * @param {string} filename - parameter
   * @param {string} contentType - parameter
   * @returns {Response}
   */
  file(content, filename, contentType) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} content - parameter
   * @param {string} filename - parameter
   * @param {string} contentType - parameter
   * @returns {Response}
   */
  file(content, filename, contentType) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} contentType - parameter
   * @param {any} body - parameter
   * @returns {Response}
   */
  raw(contentType, body) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} body - parameter
   * @returns {Response}
   */
  text(body) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} url - parameter
   * @returns {Response}
   */
  redirect(url) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {Response}
   */
  none() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {any} body - parameter
   * @returns {Response}
   */
  json(body) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} view - parameter
   * @returns {Response}
   */
  html(view) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class Response {
  constructor() {
  }

  /**
   *  
   *
   * @returns {string}
   */
  type() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {boolean}
   */
  isEmpty() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {InputStream}
   */
  stream() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {number}
   */
  status() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {string}
   */
  filename() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {any}
   */
  body() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {string}
   */
  view() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {string}
   */
  contentType() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {{[key: string]: string}}
   */
  headers() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {string}
   */
  redirectUrl() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} name - parameter
   * @param {string} value - parameter
   * @returns {Response}
   */
  withHeader(name, value) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {any} newBody - parameter
   * @returns {Response}
   */
  withBody(newBody) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {number} status - parameter
   * @returns {Response}
   */
  withStatus(status) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {number[]}
   */
  bodyBytes() { /* no-op: generated stub */ }

}

/**
 * @class
 */
class PageModelMap {
  constructor() {
  }

  /**
   *  
   *
   * @param {any} key - parameter
   * @returns {any}
   */
  get(key) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} key - parameter
   * @param {any} value - parameter
   * @returns {any}
   */
  put(key, value) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class RuntimeUtilServices {
  constructor() {
  }

  /**
   *  
   *
   * @param {any} o - parameter
   * @returns {string}
   */
  toString(o) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} s - parameter
   * @returns {number}
   */
  parseInt(s) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {number} d - parameter
   * @returns {boolean}
   */
  isNaN(d) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} s - parameter
   * @returns {number}
   */
  parseFloat(s) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} s - parameter
   * @returns {number}
   */
  parseLong(s) { /* no-op: generated stub */ }

  /**
   * Now, in the user's time zone — else the organization's, else the instance's (a ZonedDateTime). 
   *
   * @returns {ZonedDateTime}
   */
  now() { /* no-op: generated stub */ }

  /**
   * Today's date on the server's clock (as the original). For the user's today, use today(). 
   *
   * @returns {LocalDate}
   */
  dateNow() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} s - parameter
   * @returns {LocalDate}
   */
  parseDate(s) { /* no-op: generated stub */ }

  /**
   * formatDate(d, pattern) in a given locale, e.g. 'de_DE'. 
   *
   * @param {any} d - parameter
   * @param {string} pattern - parameter
   * @param {string} locale - parameter
   * @returns {string}
   */
  formatDate(d, pattern, locale) { /* no-op: generated stub */ }

  /**
   * A date or time by a pattern ('dd.MM.yyyy', 'd MMMM yyyy HH:mm') or a style ('SHORT', 'MEDIUM', 'LONG', 'FULL'), in the user's locale. Takes a LocalDate, LocalDateTime, ZonedDateTime, a JS Date or ISO text; an instant (a JS Date) is shown in the user's time zone. 
   *
   * @param {any} d - parameter
   * @param {string} pattern - parameter
   * @returns {string}
   */
  formatDate(d, pattern) { /* no-op: generated stub */ }

  /**
   * The SHA-256 hash of text (UTF-8) or bytes, as lowercase hex. 
   *
   * @param {any} value - parameter
   * @returns {string}
   */
  sha256(value) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} s - parameter
   * @returns {LocalTime}
   */
  parseTime(s) { /* no-op: generated stub */ }

  /**
   * The MD5 hash of the text, as hex. Not for security: use sha256 or hmacSha256. 
   *
   * @param {string} value - parameter
   * @returns {string}
   */
  md5(value) { /* no-op: generated stub */ }

  /**
   * formatNumber(n, pattern) in a given locale, e.g. 'de_DE'. 
   *
   * @param {any} n - parameter
   * @param {string} pattern - parameter
   * @param {string} locale - parameter
   * @returns {string}
   */
  formatNumber(n, pattern, locale) { /* no-op: generated stub */ }

  /**
   * A number by a pattern, in the user's locale: formatNumber(1234.5, '#,##0.00') gives 1,234.50 in en_US and 1 234,50 in pl_PL, rounded half up. A null pattern is the locale's usual way. 
   *
   * @param {any} n - parameter
   * @param {string} pattern - parameter
   * @returns {string}
   */
  formatNumber(n, pattern) { /* no-op: generated stub */ }

  /**
   * The time zone now() and today() use: the user's, else the organization's, else the instance's. 
   *
   * @returns {ZoneId}
   */
  timeZone() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {number} s - parameter
   * @returns {number}
   */
  asLong(s) { /* no-op: generated stub */ }

  /**
   * The signed-in user's id, or null when there is none — the same as a.user.getId(). 
   *
   * @returns {number}
   */
  getUserId() { /* no-op: generated stub */ }

  /**
   * Whether two texts (or byte arrays) are equal, taking the same time wherever they differ — for comparing signatures and tokens, where === would leak how much of a guess was right. False if either is null. 
   *
   * @param {any} a - parameter
   * @param {any} b - parameter
   * @returns {boolean}
   */
  constantTimeEquals(a, b) { /* no-op: generated stub */ }

  /**
   * hmacSha256(secret, value) as Base64. 
   *
   * @param {any} secret - parameter
   * @param {any} value - parameter
   * @returns {string}
   */
  hmacSha256Base64(secret, value) { /* no-op: generated stub */ }

  /**
   * Text (as UTF-8) or bytes as Base64. 
   *
   * @param {any} value - parameter
   * @returns {string}
   */
  base64Encode(value) { /* no-op: generated stub */ }

  /**
   * Base64 (standard or URL-safe, padded or not) back to bytes. For text, base64DecodeText. 
   *
   * @param {string} s - parameter
   * @returns {number[]}
   */
  base64Decode(s) { /* no-op: generated stub */ }

  /**
   * An amount as money in a currency (ISO code), in the user's locale: formatMoney(1234.5, 'EUR') gives €1,234.50 in en_US and 1 234,50 € in pl_PL; rounded half up to the currency's decimals. 
   *
   * @param {any} amount - parameter
   * @param {string} currency - parameter
   * @returns {string}
   */
  formatMoney(amount, currency) { /* no-op: generated stub */ }

  /**
   * formatMoney(amount, currency) in a given locale, e.g. 'de_DE'. 
   *
   * @param {any} amount - parameter
   * @param {string} currency - parameter
   * @param {string} locale - parameter
   * @returns {string}
   */
  formatMoney(amount, currency, locale) { /* no-op: generated stub */ }

  /**
   * The signed-in user's id, or -1 when there is none (as the original openkoda). Prefer getUserId(). 
   *
   * @returns {number}
   */
  getCurrentUserId() { /* no-op: generated stub */ }

  /**
   * The date and time on the server's clock (as the original). For the user's, use now(). 
   *
   * @returns {LocalDateTime}
   */
  dateTimeNow() { /* no-op: generated stub */ }

  /**
   * Today's date in the user's time zone — else the organization's, else the instance's. 
   *
   * @returns {LocalDate}
   */
  today() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} s - parameter
   * @returns {LocalDateTime}
   */
  parseDateTime(s) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} s - parameter
   * @returns {number}
   */
  parseDecimal(s) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {number} s - parameter
   * @returns {number}
   */
  asDecimal(s) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {number} s - parameter
   * @returns {number}
   */
  asDecimal(s) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {number} s - parameter
   * @returns {number}
   */
  asDecimal(s) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {number} s - parameter
   * @returns {number}
   */
  asDecimal(s) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} s - parameter
   * @returns {string}
   */
  encodeURI(s) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} uri - parameter
   * @returns {string}
   */
  decodeURI(uri) { /* no-op: generated stub */ }

  /**
   * A value — an object, a list, a record — as indented JSON text (as the original). 
   *
   * @param {any} o - parameter
   * @returns {string}
   */
  toJSON(o) { /* no-op: generated stub */ }

  /**
   * JSON text as data: an object becomes a map that also answers the original's getString(key), getInt, getLong, getDouble, getBoolean, getJSONObject, getJSONArray, has, opt and optString; an array becomes a list. Text that is not JSON throws. JSON.parse(s) in the code works too. 
   *
   * @param {string} s - parameter
   * @returns {any}
   */
  parseJSON(s) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {string}
   */
  getUUID() { /* no-op: generated stub */ }

  /**
   * A random number from 0 (inclusive) to 1 (exclusive). 
   *
   * @returns {number}
   */
  getRandomDouble() { /* no-op: generated stub */ }

  /**
   * A random whole number, any long — from a secure random source. 
   *
   * @returns {number}
   */
  getRandomLong() { /* no-op: generated stub */ }

  /**
   * Base64 back to text (UTF-8) — e.g. the middle part of a JWT. 
   *
   * @param {string} s - parameter
   * @returns {string}
   */
  base64DecodeText(s) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {any} value - parameter
   * @param {string} condition - parameter
   * @returns {boolean}
   */
  doEvaluateToBoolean(value, condition) { /* no-op: generated stub */ }

  /**
   * The date n business days after date (before it when n < 0), by the 'default' business calendar, or Monday to Friday when the program declares none. Adding 1 to a Friday gives the Monday. 
   *
   * @param {any} date - parameter
   * @param {number} n - parameter
   * @returns {LocalDate}
   */
  addBusinessDays(date, n) { /* no-op: generated stub */ }

  /**
   * addBusinessDays(date, n) by a calendar declared with system.newBusinessCalendar(name). 
   *
   * @param {any} date - parameter
   * @param {number} n - parameter
   * @param {string} calendarName - parameter
   * @returns {LocalDate}
   */
  addBusinessDays(date, n, calendarName) { /* no-op: generated stub */ }

  /**
   * isBusinessDay(date) by a calendar declared with system.newBusinessCalendar(name). 
   *
   * @param {any} date - parameter
   * @param {string} calendarName - parameter
   * @returns {boolean}
   */
  isBusinessDay(date, calendarName) { /* no-op: generated stub */ }

  /**
   * Whether date is a working day by the 'default' business calendar (Monday to Friday when the program declares none). 
   *
   * @param {any} date - parameter
   * @returns {boolean}
   */
  isBusinessDay(date) { /* no-op: generated stub */ }

  /**
   * A random token of 32 bytes from a secure random source, as URL-safe Base64 (43 characters): for invitation links, API keys, nonces. 
   *
   * @returns {string}
   */
  randomToken() { /* no-op: generated stub */ }

  /**
   * A random token of the given number of bytes (1 to 1024), as URL-safe Base64 without padding. 
   *
   * @param {number} bytes - parameter
   * @returns {string}
   */
  randomToken(bytes) { /* no-op: generated stub */ }

  /**
   * The SHA-256 hash of text (UTF-8) or bytes, as Base64. 
   *
   * @param {any} value - parameter
   * @returns {string}
   */
  sha256Base64(value) { /* no-op: generated stub */ }

  /**
   * The HMAC-SHA256 of text or bytes with a secret, as lowercase hex — to sign a webhook, or to check one's signature with constantTimeEquals(expected, received). 
   *
   * @param {any} secret - parameter
   * @param {any} value - parameter
   * @returns {string}
   */
  hmacSha256(secret, value) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class ServiceLogger {
  constructor() {
  }

  /**
   *  
   *
   * @param {string} format - parameter
   * @param {any[]} arguments - parameter
   * @returns {void}
   */
  info(format, arguments) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} format - parameter
   * @param {any[]} arguments - parameter
   * @returns {void}
   */
  trace(format, arguments) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} message - parameter
   * @param {Throwable} throwable - parameter
   * @returns {void}
   */
  error(message, throwable) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} format - parameter
   * @param {any[]} arguments - parameter
   * @returns {void}
   */
  error(format, arguments) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} format - parameter
   * @param {any[]} arguments - parameter
   * @returns {void}
   */
  warn(format, arguments) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} message - parameter
   * @param {Throwable} throwable - parameter
   * @returns {void}
   */
  warn(message, throwable) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} format - parameter
   * @param {any[]} arguments - parameter
   * @returns {void}
   */
  debug(format, arguments) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class RuntimeSystemServices {
  constructor() {
  }

  /**
   *  
   *
   * @param {string} name - parameter
   * @returns {ServiceLogger}
   */
  getLogger(name) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {ServiceLogger}
   */
  getLogger() { /* no-op: generated stub */ }

  /**
   * The instance's public address, e.g. 'https://crm.example.com' (no trailing slash) — for links that leave the page: emails, PDFs, webhooks, OAuth callbacks. Join a path: getBaseUrl() + '/html/organization/' + id + '/dashboard'. Null when the instance has none configured. 
   *
   * @returns {string}
   */
  getBaseUrl() { /* no-op: generated stub */ }

  /**
   * A secret's value as another organization sees it (its own, else the instance-wide one). Allowed for the request's own organization, one the user belongs to, a user who may access secrets globally, and code that runs as the system (cron, events) — not an anonymous visitor of a public route. Anything else throws. 
   *
   * @param {string} name - parameter
   * @param {number} organizationId - parameter
   * @returns {string}
   */
  getSecret(name, organizationId) { /* no-op: generated stub */ }

  /**
   * A secret's value by name, or null when there is none: the organization's own secret if it has one, else the instance-wide one (both kept encrypted, edited under Security > Secrets), else the instance's configuration property superkoda.secrets.<name> (what the operator provisions), else an environment variable of that name if the instance lists it in superkoda.runtime.js.env-secrets. Pass it straight to where it is used, e.g. a request header; never log it or put it in a page. 
   *
   * @param {string} name - parameter
   * @returns {string}
   */
  getSecret(name) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class Messages {
  constructor() {
  }

  /**
   *  
   *
   * @param {any[]} args - parameter
   * @returns {any}
   */
  sendEmail(args) { /* no-op: generated stub */ }

  /**
   * Push an event to every page this user has open: sendToWebsocketUser(userId or user, 'invoice-updated', {id: 7}). In the page: new EventSource('/api/v1/live').addEventListener('invoice-updated', e => JSON.parse(e.data)). Sent once this flow's transaction commits; true when queued. A user who has no page open does not get it later — for that, create a notification. 
   *
   * @param {any} user - parameter
   * @param {string} event - parameter
   * @param {any} payload - parameter
   * @returns {boolean}
   */
  sendToWebsocketUser(user, event, payload) { /* no-op: generated stub */ }

  /**
   * Push an event to the pages subscribed to a channel: sendToWebsocketChannel('org-' + orgId + '/dashboard', 'refresh', {at: …}). Pages subscribe with new EventSource('/api/v1/live?channel=…'); a channel 'org-<id>' or 'org-<id>/…' only reaches members of that organization. Sent once this flow's transaction commits. 
   *
   * @param {string} channel - parameter
   * @param {string} event - parameter
   * @param {any} payload - parameter
   * @returns {boolean}
   */
  sendToWebsocketChannel(channel, event, payload) { /* no-op: generated stub */ }

  /**
   * The original's form: sendToWebsocketChannel(channel, payload), as the event 'message'. 
   *
   * @param {string} channel - parameter
   * @param {any} payload - parameter
   * @returns {boolean}
   */
  sendToWebsocketChannel(channel, payload) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class EventsService {
  constructor() {
  }

  /**
   * Notify every member of an organization: createOrganizationNotification(organizationId, message[, {level, url, subject, privilege}]). Your own organization (any, for the system or canManageBackend). 
   *
   * @param {any} organizationId - parameter
   * @param {string} message - parameter
   * @returns {any}
   */
  createOrganizationNotification(organizationId, message) { /* no-op: generated stub */ }

  /**
   * createOrganizationNotification(organizationId, message) with {level, url, subject, privilege}. 
   *
   * @param {any} organizationId - parameter
   * @param {string} message - parameter
   * @param {any} options - parameter
   * @returns {any}
   */
  createOrganizationNotification(organizationId, message, options) { /* no-op: generated stub */ }

  /**
   * The original's form: createOrganizationNotification(type, message, organizationId, requiredPrivilege, attachmentURL). 
   *
   * @param {string} type - parameter
   * @param {string} message - parameter
   * @param {number} organizationId - parameter
   * @param {string} requiredPrivilege - parameter
   * @param {string} attachmentURL - parameter
   * @returns {any}
   */
  createOrganizationNotification(type, message, organizationId, requiredPrivilege, attachmentURL) { /* no-op: generated stub */ }

  /**
   * The original's form: createGlobalNotification(type, message, requiredPrivilege, attachmentURL). 
   *
   * @param {string} type - parameter
   * @param {string} message - parameter
   * @param {string} requiredPrivilege - parameter
   * @param {string} attachmentURL - parameter
   * @returns {any}
   */
  createGlobalNotification(type, message, requiredPrivilege, attachmentURL) { /* no-op: generated stub */ }

  /**
   * createGlobalNotification(message) with {level, url, subject, privilege}. 
   *
   * @param {string} message - parameter
   * @param {any} options - parameter
   * @returns {any}
   */
  createGlobalNotification(message, options) { /* no-op: generated stub */ }

  /**
   * Notify every user: createGlobalNotification(message[, {level, url, subject, privilege}]). For the system and canManageBackend holders. 
   *
   * @param {string} message - parameter
   * @returns {any}
   */
  createGlobalNotification(message) { /* no-op: generated stub */ }

  /**
   * createUserNotification(user, message, {level: 'INFO'|'SUCCESS'|'WARNING'|'ERROR', url: '/html/…' (opened from the bell), subject, privilege: only users holding it see it}). 
   *
   * @param {any} user - parameter
   * @param {string} message - parameter
   * @param {any} options - parameter
   * @returns {any}
   */
  createUserNotification(user, message, options) { /* no-op: generated stub */ }

  /**
   * The original's form: createUserNotification(type, message, requiredPrivilege, userId, attachmentURL). 
   *
   * @param {string} type - parameter
   * @param {string} message - parameter
   * @param {string} requiredPrivilege - parameter
   * @param {number} userId - parameter
   * @param {string} attachmentURL - parameter
   * @returns {any}
   */
  createUserNotification(type, message, requiredPrivilege, userId, attachmentURL) { /* no-op: generated stub */ }

  /**
   * Notify one user: createUserNotification(userId or user, 'Invoice approved'). Shows in their bell until read. Allowed for yourself and members of your organization (anyone, for the system or canManageBackend). Saved with this flow's transaction. 
   *
   * @param {any} user - parameter
   * @param {string} message - parameter
   * @returns {any}
   */
  createUserNotification(user, message) { /* no-op: generated stub */ }

  /**
   * The original's form: createRoleOrganizationNotification(type, message, organizationId, requiredPrivilege, attachmentURL, roleId). 
   *
   * @param {string} type - parameter
   * @param {string} message - parameter
   * @param {number} organizationId - parameter
   * @param {string} requiredPrivilege - parameter
   * @param {string} attachmentURL - parameter
   * @param {number} roleId - parameter
   * @returns {any}
   */
  createRoleOrganizationNotification(type, message, organizationId, requiredPrivilege, attachmentURL, roleId) { /* no-op: generated stub */ }

  /**
   * Emit a custom event, with an optional payload, to the flows routed with system.eventRouter.on('CUSTOM', name, flow). They run asynchronously. Inside a transaction (runInTransaction, a .transactional() route) it is sent when that commits, and dropped if it rolls back. 
   *
   * @param {string} name - parameter
   * @param {any} payload - parameter
   * @returns {void}
   */
  emitEventAsync(name, payload) { /* no-op: generated stub */ }

  /**
   * Emit a custom event with no payload; see emitEventAsync(name, payload). 
   *
   * @param {string} name - parameter
   * @returns {void}
   */
  emitEventAsync(name) { /* no-op: generated stub */ }

  /**
   * createRoleNotification(organizationId, role, message) with {level, url, subject, privilege}. 
   *
   * @param {any} organizationId - parameter
   * @param {any} role - parameter
   * @param {string} message - parameter
   * @param {any} options - parameter
   * @returns {any}
   */
  createRoleNotification(organizationId, role, message, options) { /* no-op: generated stub */ }

  /**
   * Notify the users holding a role in an organization: createRoleNotification(organizationId, 'ROLE_ACCOUNTANT' or roleId, message[, {level, url, subject, privilege}]). 
   *
   * @param {any} organizationId - parameter
   * @param {any} role - parameter
   * @param {string} message - parameter
   * @returns {any}
   */
  createRoleNotification(organizationId, role, message) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class Integrations {
  constructor() {
  }

  /**
   * postAsync(url, body) with request headers ({name: value}). 
   *
   * @param {string} url - parameter
   * @param {any} body - parameter
   * @param {any} headers - parameter
   * @returns {number}
   */
  postAsync(url, body, headers) { /* no-op: generated stub */ }

  /**
   * POST a body (an object, sent as JSON, or a string) in the background and return the queued post's id: it is sent after this flow's transaction commits (never if it rolls back), and retried with a growing pause until the URL answers 2xx. For webhooks; use restPost to read an answer. 
   *
   * @param {string} url - parameter
   * @param {any} body - parameter
   * @returns {number}
   */
  postAsync(url, body) { /* no-op: generated stub */ }

  /**
   * Post a text message to a Slack incoming-webhook URL, in the background (as the original openkoda's sendMessageToSlack). True once it is queued. 
   *
   * @param {string} message - parameter
   * @param {string} webHook - parameter
   * @returns {boolean}
   */
  sendMessageToSlack(message, webHook) { /* no-op: generated stub */ }

  /**
   * sendMessageToSlack(message, webHook) to a channel, as a user name; either may be null. 
   *
   * @param {string} message - parameter
   * @param {string} webHook - parameter
   * @param {string} channel - parameter
   * @param {string} username - parameter
   * @returns {boolean}
   */
  sendMessageToSlack(message, webHook, channel, username) { /* no-op: generated stub */ }

  /**
   * Post a Slack message given as JSON text (blocks, attachments …) to an incoming-webhook URL, in the background. True once it is queued. 
   *
   * @param {string} jsonMessage - parameter
   * @param {string} webHook - parameter
   * @returns {boolean}
   */
  sendJsonMessageToSlack(jsonMessage, webHook) { /* no-op: generated stub */ }

  /**
   * GET a URL and return the body as text: JSON.parse(context.services.integrations.httpGet(url)). 
   *
   * @param {string} url - parameter
   * @returns {string}
   */
  httpGet(url) { /* no-op: generated stub */ }

  /**
   * GET a URL with request headers ({name: value}) and return the body as text. 
   *
   * @param {string} url - parameter
   * @param {any} headers - parameter
   * @returns {string}
   */
  httpGet(url, headers) { /* no-op: generated stub */ }

  /**
   * GET a URL that answers JSON, with request headers ({name: value}), and return it as a map. 
   *
   * @param {string} url - parameter
   * @param {any} headers - parameter
   * @returns {any}
   */
  restGet(url, headers) { /* no-op: generated stub */ }

  /**
   * GET a URL that answers JSON and return it as a map. 
   *
   * @param {string} url - parameter
   * @returns {any}
   */
  restGet(url) { /* no-op: generated stub */ }

  /**
   * POST a body (an object, sent as JSON, or a string) and return the JSON answer as a map. 
   *
   * @param {string} url - parameter
   * @param {any} body - parameter
   * @returns {any}
   */
  restPost(url, body) { /* no-op: generated stub */ }

  /**
   * POST a body (an object, sent as JSON, or a string) with request headers and return the JSON answer as a map. 
   *
   * @param {string} url - parameter
   * @param {any} body - parameter
   * @param {any} headers - parameter
   * @returns {any}
   */
  restPost(url, body, headers) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class Documents {
  constructor() {
  }

  /**
   * A PDF of a web resource rendered as a Thymeleaf template with the model, e.g. htmlToPdf('/html/invoice-print', {invoice: inv}) or htmlToPdf('/html/invoice-print', a.model). An array of models prints each one starting on a new page. The page may load its own CSS and images by path (/css/print.css) or as data: URIs, nothing from the network; @page {size: A4; margin: 2cm} sets the paper. Rendered in the user's locale. Returns the PDF's bytes. 
   *
   * @param {string} path - parameter
   * @returns {number[]}
   */
  htmlToPdf(path) { /* no-op: generated stub */ }

  /**
   * CSV bytes (UTF-8) of rows: maps (e.g. from repo.select) or arrays. Options: headers — the keys to write, in order (default every key), or {key: 'Label'} to head them differently; separator (default ','; ';' for Excel in many European locales); header: false to leave out the head line; bom: true for Excel to read UTF-8; excelSafe: true to prefix text starting with = + - @ with ', so Excel never runs it as a formula. 
   *
   * @param {any} rows - parameter
   * @returns {number[]}
   */
  toCsv(rows) { /* no-op: generated stub */ }

  /**
   * The rows of a CSV: a stored file (its id, uuid or File), bytes, or the text itself. Each row is a map by the first line's column names, its cells text (missing cells null), ready for repo.bind(row). Options: headers — false for rows as arrays, or ['a', 'b'] to name the columns when the first line is data; separator (default: guessed from the first line among , ; tab |); charset (default UTF-8, e.g. 'windows-1250'); trim: true to trim the cells. Blank lines are skipped. 
   *
   * @param {any} source - parameter
   * @returns {any[]}
   */
  parseCsv(source) { /* no-op: generated stub */ }

  /**
   * A DOCX document from a template (a file component, by its uuid) filled with the model, e.g. a.model. Tags: {{name}}, {{client.name}}; {{?vip}}…{{/vip}} kept when truthy (repeated for a list); {{*items}} in a table row repeats the row below it per item, with [title], [qty * price] in its cells; expressions like {{qty * price}}. Returns the document's bytes. 
   *
   * @param {string} documentTemplateFileComponentUuid - parameter
   * @param {PageModelMap} documentModel - parameter
   * @returns {number[]}
   */
  generateDocument(documentTemplateFileComponentUuid, documentModel) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class Sequences {
  constructor() {
  }

  /**
   * next(name) with options: {date} — the date the number belongs to, which decides its period and date parts (an invoice dated 31 December numbered in January); {organizationId} — another organization's counter, for the system or a member of it. 
   *
   * @param {string} name - parameter
   * @param {any} options - parameter
   * @returns {string}
   */
  next(name, options) { /* no-op: generated stub */ }

  /**
   * Take the next number of a sequence, formatted: next('invoice') gives e.g. 'INV-2026-0042'. Counts in this organization (unless the sequence is .global()) and in today's period. Take it inside runInTransaction or a .transactional() route, so a failed save gives the number back. 
   *
   * @param {string} name - parameter
   * @returns {string}
   */
  next(name) { /* no-op: generated stub */ }

  /**
   * peek(name) with the options of next(name, options). 
   *
   * @param {string} name - parameter
   * @param {any} options - parameter
   * @returns {string}
   */
  peek(name, options) { /* no-op: generated stub */ }

  /**
   * The number next(name) would give now, formatted, without taking it. For display only: by the time a record is saved someone else may have taken it. 
   *
   * @param {string} name - parameter
   * @returns {string}
   */
  peek(name) { /* no-op: generated stub */ }

  /**
   * setNext(name, nextValue) with the options of next(name, options). 
   *
   * @param {string} name - parameter
   * @param {number} nextValue - parameter
   * @param {any} options - parameter
   * @returns {void}
   */
  setNext(name, nextValue, options) { /* no-op: generated stub */ }

  /**
   * Make the sequence continue from nextValue in the current period (or {date}'s) — to carry on an old system's numbering. Needs canManageBackend, or runs as the system. 
   *
   * @param {string} name - parameter
   * @param {number} nextValue - parameter
   * @returns {void}
   */
  setNext(name, nextValue) { /* no-op: generated stub */ }

  /**
   * nextValue(name) with the options of next(name, options). 
   *
   * @param {string} name - parameter
   * @param {any} options - parameter
   * @returns {number}
   */
  nextValue(name, options) { /* no-op: generated stub */ }

  /**
   * Take the next number as a bare number (42), without the format. 
   *
   * @param {string} name - parameter
   * @returns {number}
   */
  nextValue(name) { /* no-op: generated stub */ }

}

/**
 * @class
 * @implements FileInterface
 * @implements AuditableEntity
 */
class File {
  constructor() {
  }

}

/**
 * @class
 */
class Files {
  constructor() {
  }

  /**
   * The file with this id or uuid, or null when there is none this flow may see. Metadata only. 
   *
   * @param {any} file - parameter
   * @returns {File}
   */
  get(file) { /* no-op: generated stub */ }

  /**
   * A copy of a file, as a new file of the same organization. 
   *
   * @param {any} file - parameter
   * @returns {File}
   */
  copy(file) { /* no-op: generated stub */ }

  /**
   * The file's bytes. 
   *
   * @param {any} file - parameter
   * @returns {number[]}
   */
  bytes(file) { /* no-op: generated stub */ }

  /**
   * Several files at once: a list of ids or uuids, or the text an entity files() field holds (ids separated by commas). Ones that do not exist or may not be seen are left out. 
   *
   * @param {any} files - parameter
   * @returns {File[]}
   */
  list(files) { /* no-op: generated stub */ }

  /**
   * The file's download URL, /file/stored/{uuid}. Opening it needs a signed-in user who may read files in its organization, unless the file is public. 
   *
   * @param {any} file - parameter
   * @returns {string}
   */
  url(file) { /* no-op: generated stub */ }

  /**
   * Store content — bytes or text — as a file: files.save(pdf, 'invoice.pdf', 'application/pdf'). 
   *
   * @param {any} content - parameter
   * @param {string} filename - parameter
   * @param {string} contentType - parameter
   * @returns {File}
   */
  save(content, filename, contentType) { /* no-op: generated stub */ }

  /**
   * Store an upload — files.save(a.web.requestParameters.getAsFile('scan')) — or, given an options object, {content, filename, contentType, organizationId, public}. Content is bytes (e.g. what documents.generateDocument returns) or text. Returns the stored File: getId(), getUploadUuid(), getFilename(), getContentType(), getSize(). 
   *
   * @param {any} uploadOrOptions - parameter
   * @returns {File}
   */
  save(uploadOrOptions) { /* no-op: generated stub */ }

  /**
   * Delete the file. True when it existed and was deleted. 
   *
   * @param {any} file - parameter
   * @returns {boolean}
   */
  delete(file) { /* no-op: generated stub */ }

  /**
   * The file's content as UTF-8 text — for CSV, JSON or text uploads. 
   *
   * @param {any} file - parameter
   * @returns {string}
   */
  text(file) { /* no-op: generated stub */ }

  /**
   * Answer a request with the file: .respond(a => a.services.files.download(id)) — saved under its name by the browser. 
   *
   * @param {any} file - parameter
   * @returns {Response}
   */
  download(file) { /* no-op: generated stub */ }

  /**
   * download(file) with {inline: true} to show it in the browser (a PDF, an image) rather than save it. 
   *
   * @param {any} file - parameter
   * @param {any} options - parameter
   * @returns {Response}
   */
  download(file, options) { /* no-op: generated stub */ }

  /**
   * publicUrl(file) with {expiresInSeconds} (default 3600, at most 30 days). 
   *
   * @param {any} file - parameter
   * @param {any} options - parameter
   * @returns {string}
   */
  publicUrl(file, options) { /* no-op: generated stub */ }

  /**
   * A link anyone may download the file with for an hour — to put in an email, say. 
   *
   * @param {any} file - parameter
   * @returns {string}
   */
  publicUrl(file) { /* no-op: generated stub */ }

  /**
   * A new file holding the image scaled to the given width, keeping its proportions — for thumbnails. PNG and JPEG keep their format; anything else becomes PNG. 
   *
   * @param {any} file - parameter
   * @param {number} width - parameter
   * @returns {File}
   */
  scaleImage(file, width) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class Jobs {
  constructor() {
  }

  /**
   * The job in detail: {id, name, status, attempts, maxAttempts, lastError, runAt, organizationId, userId}. 
   *
   * @param {number} id - parameter
   * @returns {{[key: string]: any}}
   */
  get(id) { /* no-op: generated stub */ }

  /**
   * How the job is doing: 'QUEUED' (waiting, or waiting to try again), 'RUNNING', 'DONE', 'FAILED' (out of attempts) or 'CANCELLED'. 
   *
   * @param {number} id - parameter
   * @returns {string}
   */
  status(id) { /* no-op: generated stub */ }

  /**
   * Queue the job declared with system.eventRouter.job(name, flow) and return its id. It runs later on a worker, as you, in this organization; if this flow's transaction rolls back, it is never queued. 
   *
   * @param {string} name - parameter
   * @returns {number}
   */
  enqueue(name) { /* no-op: generated stub */ }

  /**
   * enqueue(name) with a payload — an object the job reads as a.event.payload(). 
   *
   * @param {string} name - parameter
   * @param {any} payload - parameter
   * @returns {number}
   */
  enqueue(name, payload) { /* no-op: generated stub */ }

  /**
   * enqueue(name, payload) with options: {delaySeconds} or {runAt} (a date-time) to start it later; {uniqueKey: 'reminder-7-2026-10-13'} to queue it once — a second enqueue with the key gives back the first job's id. 
   *
   * @param {string} name - parameter
   * @param {any} payload - parameter
   * @param {any} options - parameter
   * @returns {number}
   */
  enqueue(name, payload, options) { /* no-op: generated stub */ }

  /**
   * Cancel a job that has not run yet, or is waiting to try again. True when it was cancelled; a running, finished or failed job is left as it is. 
   *
   * @param {number} id - parameter
   * @returns {boolean}
   */
  cancel(id) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class OrganizationMember {
  constructor() {
  }

  /**
   * First and last name, or the email when the user has no name. 
   *
   * @returns {string}
   */
  getName() { /* no-op: generated stub */ }

  /**
   * The user's id. 
   *
   * @returns {number}
   */
  getId() { /* no-op: generated stub */ }

  /**
   * The user's role in this organization, e.g. 'ROLE_ORG_USER'. 
   *
   * @returns {string}
   */
  getRole() { /* no-op: generated stub */ }

  /**
   * The user's first name, or null. 
   *
   * @returns {string}
   */
  getFirstName() { /* no-op: generated stub */ }

  /**
   * The user's last name, or null. 
   *
   * @returns {string}
   */
  getLastName() { /* no-op: generated stub */ }

  /**
   * The user's email (their login). 
   *
   * @returns {string}
   */
  getEmail() { /* no-op: generated stub */ }

}

/**
 * @class
 */
class Users {
  constructor() {
  }

  /**
   * find(userId) in another organization the caller may read. 
   *
   * @param {number} userId - parameter
   * @param {number} organizationId - parameter
   * @returns {OrganizationMember}
   */
  find(userId, organizationId) { /* no-op: generated stub */ }

  /**
   * A member of the flow's organization by id → {getId(), getEmail(), getName(), getFirstName(), getLastName(), getRole()}, or null when that user is not a member. Needs canReadUserData. 
   *
   * @param {number} userId - parameter
   * @returns {OrganizationMember}
   */
  find(userId) { /* no-op: generated stub */ }

  /**
   * create(firstName, lastName, email): no global role, enabled. 
   *
   * @param {string} firstName - parameter
   * @param {string} lastName - parameter
   * @param {string} email - parameter
   * @returns {OrganizationMember}
   */
  create(firstName, lastName, email) { /* no-op: generated stub */ }

  /**
   * create(firstName, lastName, email, globalRoleId): enabled. 
   *
   * @param {string} firstName - parameter
   * @param {string} lastName - parameter
   * @param {string} email - parameter
   * @param {number} globalRoleId - parameter
   * @returns {OrganizationMember}
   */
  create(firstName, lastName, email, globalRoleId) { /* no-op: generated stub */ }

  /**
   * A new account in no organization yet: create(firstName, lastName, email, globalRoleId, enabled). email is also its login; globalRoleId a GLOBAL role (null = none) holding nothing you lack; enabled defaults to true. No email is sent and no password is set: the user resets it, or invite them to an organization. Needs canManageUserData globally; the instance's user limit applies. Returns the user, getRole() = the global role. 
   *
   * @param {string} firstName - parameter
   * @param {string} lastName - parameter
   * @param {string} email - parameter
   * @param {number} globalRoleId - parameter
   * @param {boolean} enabled - parameter
   * @returns {OrganizationMember}
   */
  create(firstName, lastName, email, globalRoleId, enabled) { /* no-op: generated stub */ }

  /**
   * search(term, {page: 0, size: 50, organizationId}). 
   *
   * @param {string} term - parameter
   * @param {{[key: string]: any}} options - parameter
   * @returns {OrganizationMember[]}
   */
  search(term, options) { /* no-op: generated stub */ }

  /**
   * Members of the flow's organization whose email or name contains the term (all when blank), by email: search(term) or search(term, {page, size, organizationId}); size at most 200, default 50. 
   *
   * @param {string} term - parameter
   * @returns {OrganizationMember[]}
   */
  search(term) { /* no-op: generated stub */ }

  /**
   * deactivate(userId) in another organization the caller manages. 
   *
   * @param {number} userId - parameter
   * @param {number} organizationId - parameter
   * @returns {boolean}
   */
  deactivate(userId, organizationId) { /* no-op: generated stub */ }

  /**
   * Remove a user from the flow's organization (all their roles in it). If that leaves them in no organization, their account is disabled; their access to other organizations is never touched. False when they were not a member. Needs canManageUserRoles; never yourself. 
   *
   * @param {number} userId - parameter
   * @returns {boolean}
   */
  deactivate(userId) { /* no-op: generated stub */ }

  /**
   * removeRole(userId, role) in another organization the caller manages. 
   *
   * @param {number} userId - parameter
   * @param {string} role - parameter
   * @param {number} organizationId - parameter
   * @returns {boolean}
   */
  removeRole(userId, role, organizationId) { /* no-op: generated stub */ }

  /**
   * Take the role from a member of the flow's organization; false when they did not hold it. Their only role taken, they are no longer a member. 
   *
   * @param {number} userId - parameter
   * @param {string} role - parameter
   * @returns {boolean}
   */
  removeRole(userId, role) { /* no-op: generated stub */ }

  /**
   * A member of the flow's organization by email (case ignored), or null. 
   *
   * @param {string} email - parameter
   * @returns {OrganizationMember}
   */
  findByEmail(email) { /* no-op: generated stub */ }

  /**
   * findByEmail(email) in another organization the caller may read. 
   *
   * @param {string} email - parameter
   * @param {number} organizationId - parameter
   * @returns {OrganizationMember}
   */
  findByEmail(email, organizationId) { /* no-op: generated stub */ }

  /**
   * Add someone to the flow's organization: invite(email, {role, firstName, lastName, organizationId}). role is an ORG role (required). A new account gets an email with a link to set its password; an existing one is told it was added. Needs canManageUserRoles; returns the member. 
   *
   * @param {string} email - parameter
   * @param {{[key: string]: any}} options - parameter
   * @returns {OrganizationMember}
   */
  invite(email, options) { /* no-op: generated stub */ }

  /**
   * Give a member of the flow's organization a role (an ORG role), in place of the one they had. Needs canManageUserRoles; never your own role. Returns the member. 
   *
   * @param {number} userId - parameter
   * @param {string} role - parameter
   * @returns {OrganizationMember}
   */
  assignRole(userId, role) { /* no-op: generated stub */ }

  /**
   * assignRole(userId, role) in another organization the caller manages. 
   *
   * @param {number} userId - parameter
   * @param {string} role - parameter
   * @param {number} organizationId - parameter
   * @returns {OrganizationMember}
   */
  assignRole(userId, role, organizationId) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class OrganizationInfo {
  constructor() {
  }

  /**
   * The organization's name. 
   *
   * @returns {string}
   */
  getName() { /* no-op: generated stub */ }

  /**
   * The organization's id. 
   *
   * @returns {number}
   */
  getId() { /* no-op: generated stub */ }

}

/**
 * @class
 */
class Organizations {
  constructor() {
  }

  /**
   * The flow's organization → {getId(), getName()}, or null when the flow runs in none. 
   *
   * @returns {OrganizationInfo}
   */
  current() { /* no-op: generated stub */ }

  /**
   * create(name, {ownerUserId}, {ownerOrgRoleId}) — or create(name, ownerUserId, ownerOrgRoleId). 
   *
   * @param {string} name - parameter
   * @param {Object} owner - parameter
   * @param {Object} role - parameter
   * @returns {OrganizationInfo}
   */
  create(name, owner, role) { /* no-op: generated stub */ }

  /**
   * create(name, {ownerUserId, ownerOrgRoleId}): also makes that user its member with that ORG role (by id), in one transaction. The role may hold nothing you lack. 
   *
   * @param {string} name - parameter
   * @param {Object} owner - parameter
   * @returns {OrganizationInfo}
   */
  create(name, owner) { /* no-op: generated stub */ }

  /**
   * Create an organization: create(name). Needs canEditOrganizationData globally; the instance's organization limit applies. Returns {getId(), getName()}. 
   *
   * @param {string} name - parameter
   * @returns {OrganizationInfo}
   */
  create(name) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class Ai {
  constructor() {
  }

  /**
   * A task → {id, status: QUEUED|RUNNING|DONE|FAILED|CANCELLED, result, error, costUsd, channel}, or null when it is not one of this organization's. 
   *
   * @param {number} taskId - parameter
   * @returns {{[key: string]: any}}
   */
  get(taskId) { /* no-op: generated stub */ }

  /**
   * Start an agent task: an agent on the Studio does the prompt on this instance through its MCP, as a key of the current user's. Returns the task id; watch it with channel(id). DEV instances with the Studio uplink only. 
   *
   * @param {string} prompt - parameter
   * @returns {number}
   */
  task(prompt) { /* no-op: generated stub */ }

  /**
   * task(prompt, {privileges: ['canAccessWebResources', …] (default: the Studio's), timeLimitMinutes: 30 (at most 240), context: any JSON the agent gets with the prompt}). 
   *
   * @param {string} prompt - parameter
   * @param {{[key: string]: any}} options - parameter
   * @returns {number}
   */
  task(prompt, options) { /* no-op: generated stub */ }

  /**
   * Stop a task; false when it was over already or the user may not stop it. 
   *
   * @param {number} taskId - parameter
   * @returns {boolean}
   */
  cancel(taskId) { /* no-op: generated stub */ }

  /**
   * The live channel a task's steps are pushed to: subscribe with /api/v1/live?channel=…, or show them with the agent-task widget. 
   *
   * @param {number} taskId - parameter
   * @returns {string}
   */
  channel(taskId) { /* no-op: generated stub */ }

}

/**
 * @class
 * @property {Ai} ai - Agent tasks (DEV, with the Studio uplink): task(prompt, {privileges, timeLimitMinutes, context}) returns an id; get(id), cancel(id), channel(id) for the live steps.
 * @property {DataServicesProxy} data - 
 * @property {Documents} documents - 
 * @property {EventsService} event - 
 * @property {Files} files - Files stored in the database: save an upload or generated bytes, get, bytes, text, list, delete, copy, scaleImage, download (to answer with), url and publicUrl (a signed, expiring link).
 * @property {Integrations} integrations - 
 * @property {Jobs} jobs - Background jobs declared with system.eventRouter.job(name, flow): enqueue(name, payload, {delaySeconds, runAt, uniqueKey}) returns an id; status(id), get(id), cancel(id).
 * @property {Messages} messages - 
 * @property {Organizations} organizations - Organizations: create(name, {ownerUserId, ownerOrgRoleId}) makes one, its owner a member with that ORG role (needs canEditOrganizationData globally); current() → the flow's, {getId(), getName()}.
 * @property {Sequences} sequences - Numbers from the sequences declared with system.newSequence: next('invoice') gives e.g. 'INV-2026-0042'; nextValue, peek, setNext.
 * @property {RuntimeSystemServices} system - 
 * @property {Users} users - The users of the flow's organization, never of the whole instance: find(id), findByEmail, search(term, {page, size}), invite(email, {role, firstName, lastName}), assignRole(id, role), removeRole(id, role), deactivate(id). A user is {getId(), getEmail(), getName(), getRole()}.
 * @property {RuntimeUtilServices} util - 
 */
class RuntimeServices {
  constructor() {
    /** @type {Ai} - Agent tasks (DEV, with the Studio uplink): task(prompt, {privileges, timeLimitMinutes, context}) returns an id; get(id), cancel(id), channel(id) for the live steps. */
    this.ai = null;

    /** @type {DataServicesProxy} -  */
    this.data = null;

    /** @type {Documents} -  */
    this.documents = null;

    /** @type {EventsService} -  */
    this.event = null;

    /** @type {Files} - Files stored in the database: save an upload or generated bytes, get, bytes, text, list, delete, copy, scaleImage, download (to answer with), url and publicUrl (a signed, expiring link). */
    this.files = null;

    /** @type {Integrations} -  */
    this.integrations = null;

    /** @type {Jobs} - Background jobs declared with system.eventRouter.job(name, flow): enqueue(name, payload, {delaySeconds, runAt, uniqueKey}) returns an id; status(id), get(id), cancel(id). */
    this.jobs = null;

    /** @type {Messages} -  */
    this.messages = null;

    /** @type {Organizations} - Organizations: create(name, {ownerUserId, ownerOrgRoleId}) makes one, its owner a member with that ORG role (needs canEditOrganizationData globally); current() → the flow's, {getId(), getName()}. */
    this.organizations = null;

    /** @type {Sequences} - Numbers from the sequences declared with system.newSequence: next('invoice') gives e.g. 'INV-2026-0042'; nextValue, peek, setNext. */
    this.sequences = null;

    /** @type {RuntimeSystemServices} -  */
    this.system = null;

    /** @type {Users} - The users of the flow's organization, never of the whole instance: find(id), findByEmail, search(term, {page, size}), invite(email, {role, firstName, lastName}), assignRole(id, role), removeRole(id, role), deactivate(id). A user is {getId(), getEmail(), getName(), getRole()}. */
    this.users = null;

    /** @type {RuntimeUtilServices} -  */
    this.util = null;

  }

}

/**
 * @class
 * @implements ParametersService
 */
class SystemSettingsMap {
  constructor() {
  }

  /**
   *  
   *
   * @param {number} organizationId - parameter
   * @param {string} propertyName - parameter
   * @returns {number}
   */
  getAsLong(organizationId, propertyName) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} propertyName - parameter
   * @returns {number}
   */
  getAsLong(propertyName) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} propertyName - parameter
   * @returns {boolean}
   */
  getAsBoolean(propertyName) { /* no-op: generated stub */ }

  /**
   * Overrides the setting for the rest of this request; nothing is stored 
   *
   * @param {number} organizationId - parameter
   * @param {string} propertyName - parameter
   * @param {string} value - parameter
   * @returns {void}
   */
  setAsText(organizationId, propertyName, value) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} propertyName - parameter
   * @returns {string}
   */
  getAsText(propertyName) { /* no-op: generated stub */ }

  /**
   * The setting as organizationId has it (its own, else the global one), as text 
   *
   * @param {number} organizationId - parameter
   * @param {string} propertyName - parameter
   * @returns {string}
   */
  getAsText(organizationId, propertyName) { /* no-op: generated stub */ }

  /**
   * Overrides the setting for the rest of this request; nothing is stored 
   *
   * @param {number} organizationId - parameter
   * @param {string} propertyName - parameter
   * @param {number} value - parameter
   * @returns {void}
   */
  setAsLong(organizationId, propertyName, value) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {number} organizationId - parameter
   * @param {string} propertyName - parameter
   * @returns {number}
   */
  getAsDecimal(organizationId, propertyName) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} propertyName - parameter
   * @returns {number}
   */
  getAsDecimal(propertyName) { /* no-op: generated stub */ }

}

/**
 * @class
 * @implements ParametersService
 */
class RequestParametersMap {
  constructor() {
  }

  /**
   *  
   *
   * @param {string} propertyName - parameter
   * @returns {number}
   */
  getAsLong(propertyName) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} propertyName - parameter
   * @returns {boolean}
   */
  getAsBoolean(propertyName) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} propertyName - parameter
   * @returns {string}
   */
  getAsText(propertyName) { /* no-op: generated stub */ }

  /**
   * All files uploaded in this form field (<input type="file" multiple>); an empty list when none. 
   *
   * @param {string} propertyName - parameter
   * @returns {MultipartFile[]}
   */
  getAsFiles(propertyName) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} propertyName - parameter
   * @returns {number}
   */
  getAsDecimal(propertyName) { /* no-op: generated stub */ }

  /**
   * The file uploaded in this form field, or null — keep it with a.services.files.save(...). The form must be sent as multipart/form-data. 
   *
   * @param {string} propertyName - parameter
   * @returns {MultipartFile}
   */
  getAsFile(propertyName) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class FlowRequest {
  constructor() {
  }

  /**
   * The HTTP method: GET, POST, … 
   *
   * @returns {string}
   */
  getMethod() { /* no-op: generated stub */ }

  /**
   * The request body as bytes. The body can be read once. 
   *
   * @returns {InputStream}
   */
  getInputStream() { /* no-op: generated stub */ }

  /**
   * A request attribute that is plain data (text, number, flag), or the CSRF token under '_csrf' (getToken(), getHeaderName(), getParameterName()); null for anything else. 
   *
   * @param {string} name - parameter
   * @returns {any}
   */
  getAttribute(name) { /* no-op: generated stub */ }

  /**
   * A request header, or null. 
   *
   * @param {string} name - parameter
   * @returns {string}
   */
  getHeader(name) { /* no-op: generated stub */ }

  /**
   * Every value of a request header, as the servlet API gives it (hasMoreElements/nextElement). 
   *
   * @param {string} name - parameter
   * @returns {Enumeration<string>}
   */
  getHeaders(name) { /* no-op: generated stub */ }

  /**
   * The query string, or null. 
   *
   * @returns {string}
   */
  getQueryString() { /* no-op: generated stub */ }

  /**
   * A request parameter (query string or form), or null. a.web.requestParameters has typed getters. 
   *
   * @param {string} name - parameter
   * @returns {string}
   */
  getParameter(name) { /* no-op: generated stub */ }

  /**
   * The cookies (getName(), getValue()), or null when there are none. 
   *
   * @returns {Cookie[]}
   */
  getCookies() { /* no-op: generated stub */ }

  /**
   * The caller's IP address. 
   *
   * @returns {string}
   */
  getRemoteAddr() { /* no-op: generated stub */ }

  /**
   * The parameter names (hasMoreElements/nextElement). 
   *
   * @returns {Enumeration<string>}
   */
  getParameterNames() { /* no-op: generated stub */ }

  /**
   * The path, without the query string: /api/v1/… 
   *
   * @returns {string}
   */
  getRequestURI() { /* no-op: generated stub */ }

  /**
   * The full URL, without the query string. 
   *
   * @returns {string}
   */
  getRequestURL() { /* no-op: generated stub */ }

  /**
   * A cookie's value, or null. 
   *
   * @param {string} name - parameter
   * @returns {string}
   */
  getCookie(name) { /* no-op: generated stub */ }

  /**
   * The request body as lines: getReader().readLine(). The body can be read once. 
   *
   * @returns {BufferedReader}
   */
  getReader() { /* no-op: generated stub */ }

  /**
   * The names of the request headers (hasMoreElements/nextElement). 
   *
   * @returns {Enumeration<string>}
   */
  getHeaderNames() { /* no-op: generated stub */ }

  /**
   * The request body as text — for a JSON or XML body. Can be read once; empty after a form or upload has been parsed. 
   *
   * @returns {string}
   */
  getBodyText() { /* no-op: generated stub */ }

}

/**
 * @class
 */
class FlowResponse {
  constructor() {
  }

  /**
   * Set the HTTP status: 201, 404, … 
   *
   * @param {number} status - parameter
   * @returns {void}
   */
  setStatus(status) { /* no-op: generated stub */ }

  /**
   * Set a cookie: addCookie('theme', 'dark', {maxAge: 86400, path: '/', httpOnly: true, secure: true, sameSite: 'Lax'}). Options are optional. 
   *
   * @param {string} name - parameter
   * @param {string} value - parameter
   * @param {{[key: string]: any}} options - parameter
   * @returns {void}
   */
  addCookie(name, value, options) { /* no-op: generated stub */ }

  /**
   * Set a response header, replacing any value it had. 
   *
   * @param {string} name - parameter
   * @param {string} value - parameter
   * @returns {void}
   */
  setHeader(name, value) { /* no-op: generated stub */ }

  /**
   * Add a value to a response header. 
   *
   * @param {string} name - parameter
   * @param {string} value - parameter
   * @returns {void}
   */
  addHeader(name, value) { /* no-op: generated stub */ }

}

/**
 * @class
 * @property {any} form - 
 * @property {FlowRequest} request - 
 * @property {RequestParametersMap} requestParameters - 
 * @property {FlowResponse} response - 
 */
class WebEvent {
  constructor() {
    /** @type {any} -  */
    this.form = null;

    /** @type {FlowRequest} -  */
    this.request = null;

    /** @type {RequestParametersMap} -  */
    this.requestParameters = null;

    /** @type {FlowResponse} -  */
    this.response = null;

  }

}

/**
 * @class
 */
class Event {
  constructor() {
  }

}

/**
 * @class
 */
class CurrentUser {
  constructor() {
  }

  /**
   * The user's first and last name, or the email when the user has no name; null when there is no user. 
   *
   * @returns {string}
   */
  getName() { /* no-op: generated stub */ }

  /**
   * The signed-in user's id, or null when there is none (cron, events, an anonymous visitor). 
   *
   * @returns {number}
   */
  getId() { /* no-op: generated stub */ }

  /**
   * The time zone to show the user times in: the user's own, else the organization's, else the instance's (ADR 0066). 
   *
   * @returns {ZoneId}
   */
  getTimeZone() { /* no-op: generated stub */ }

  /**
   * The user's language, e.g. 'pl' — what the UI is shown in; null when the user has none set. 
   *
   * @returns {string}
   */
  getLocale() { /* no-op: generated stub */ }

  /**
   * True when no user is signed in: the flow runs for the system or an anonymous visitor. 
   *
   * @returns {boolean}
   */
  isAnonymous() { /* no-op: generated stub */ }

  /**
   * Whether the user holds the privilege in the given organization, or globally. 
   *
   * @param {string} privilege - parameter
   * @param {number} organizationId - parameter
   * @returns {boolean}
   */
  can(privilege, organizationId) { /* no-op: generated stub */ }

  /**
   * Whether the user holds the privilege in the organization the flow runs in, or globally — e.g. a.user.can('canApproveInvoice'). False for anonymous. 
   *
   * @param {string} privilege - parameter
   * @returns {boolean}
   */
  can(privilege) { /* no-op: generated stub */ }

  /**
   * Whether the user holds the privilege globally (not just in an organization). 
   *
   * @param {string} privilege - parameter
   * @returns {boolean}
   */
  hasGlobalPrivilege(privilege) { /* no-op: generated stub */ }

  /**
   * The user's first name, or null. 
   *
   * @returns {string}
   */
  getFirstName() { /* no-op: generated stub */ }

  /**
   * The user's last name, or null. 
   *
   * @returns {string}
   */
  getLastName() { /* no-op: generated stub */ }

  /**
   * The user's email (their login), or null when there is no user. 
   *
   * @returns {string}
   */
  getEmail() { /* no-op: generated stub */ }

  /**
   * Whether the user holds the privilege in the given organization. 
   *
   * @param {string} privilege - parameter
   * @param {number} organizationId - parameter
   * @returns {boolean}
   */
  hasOrgPrivilege(privilege, organizationId) { /* no-op: generated stub */ }

  /**
   * The privileges the user holds globally. 
   *
   * @returns {string[]}
   */
  globalPrivileges() { /* no-op: generated stub */ }

  /**
   * The privileges the user holds per organization: organization id → privilege names. 
   *
   * @returns {{[key: string]: string[]}}
   */
  organizationPrivileges() { /* no-op: generated stub */ }

  /**
   * The ids of the organizations the user belongs to. 
   *
   * @returns {number[]}
   */
  organizationIds() { /* no-op: generated stub */ }

  /**
   * The ids of the organizations where the user holds the privilege. 
   *
   * @param {string} privilege - parameter
   * @returns {number[]}
   */
  organizationIdsWithPrivilege(privilege) { /* no-op: generated stub */ }

}

/**
 * @class
 * @implements IdEntity
 */
class Organization {
  constructor() {
  }

}

/**
 * @class
 * @property {ServiceLogger} serverLogger - 
 */
class DebugUtils {
  constructor() {
    /** @type {ServiceLogger} -  */
    this.serverLogger = null;

  }

  /**
   * Gets a ServerJS Logger instance for logging using logback-based system 
   *
   * @param {string} loggerName - parameter
   * @returns {ServiceLogger}
   */
  getServerLogger(loggerName) { /* no-op: generated stub */ }

}

/**
 * @class
 * @template R extends any
 * @template CP extends any
 * @property {string[]} arguments - 
 * @property {DebugUtils} debug - Includes logging and debugging Utilities
 * @property {EntityKeys} entityKey - The registered entity keys by name, e.g. context.entityKey.note is 'note' — for the calls that take an entity key. An unregistered name is undefined.
 * @property {Event} event - 
 * @property {PageModelMap} model - 
 * @property {Organization} organization - 
 * @property {ResponseFactory} response - Builds what a flow answers with: .respond(a => a.response.html('/view')), a.response.json(body), a.response.redirect(url), a.response.file(...).
 * @property {any} result - 
 * @property {RuntimeServices} services - 
 * @property {SystemSettingsMap} systemSettings - The instance's system settings by name, the organization's before the global one: a.systemSettings.getAsText('vat.rate'), getAsLong, getAsDecimal, getAsBoolean.
 * @property {CurrentUser} user - 
 * @property {WebEvent} web - 
 */
class ResultAndModel {
  constructor() {
    /** @type {string[]} -  */
    this.arguments = null;

    /** @type {DebugUtils} - Includes logging and debugging Utilities */
    this.debug = null;

    /** @type {EntityKeys} - The registered entity keys by name, e.g. context.entityKey.note is 'note' — for the calls that take an entity key. An unregistered name is undefined. */
    this.entityKey = null;

    /** @type {Event} -  */
    this.event = null;

    /** @type {PageModelMap} -  */
    this.model = null;

    /** @type {Organization} -  */
    this.organization = null;

    /** @type {ResponseFactory} - Builds what a flow answers with: .respond(a => a.response.html('/view')), a.response.json(body), a.response.redirect(url), a.response.file(...). */
    this.response = null;

    /** @type {any} -  */
    this.result = null;

    /** @type {RuntimeServices} -  */
    this.services = null;

    /** @type {SystemSettingsMap} - The instance's system settings by name, the organization's before the global one: a.systemSettings.getAsText('vat.rate'), getAsLong, getAsDecimal, getAsBoolean. */
    this.systemSettings = null;

    /** @type {CurrentUser} -  */
    this.user = null;

    /** @type {WebEvent} -  */
    this.web = null;

  }

}

/**
 * @class
 * @template I extends any
 * @template O extends any
 * @template CP extends any
 * @implements function(ResultAndModel<I, CP>): O
 * @implements BasePageAttributes
 * @implements LoggingComponent
 */
class Flow {
  constructor() {
  }

  /**
   *  
   *
   * @template N extends any
   * @param {function(ResultAndModel<O, CP>): N} after - parameter
   * @returns {Flow<I, N, CP>}
   */
  then(after) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {function(ResultAndModel<O, CP>): Response} after - parameter
   * @returns {Flow<I, any, CP>}
   */
  respond(after) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} modelKey - parameter
   * @param {function(ResultAndModel<O, CP>): any} after - parameter
   * @returns {Flow<I, any, CP>}
   */
  thenSet(modelKey, after) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class QueryExecutor {
  constructor() {
  }

  /**
   * query(sql, params) with no parameters. 
   *
   * @param {string} sql - parameter
   * @returns {{[key: string]: any}[]}
   */
  query(sql) { /* no-op: generated stub */ }

  /**
   * Run one SELECT and return its rows as objects keyed by column name: query('select title from invoice where organization_id = :org and amount > :min', {min: 5}). Read-only, on its own connection (it does not see this transaction's unsaved writes), 10 s at most, 10 000 rows at most. :org is the current organization. Needs canManageBackend, or the system. 
   *
   * @param {string} sql - parameter
   * @param {any} params - parameter
   * @returns {{[key: string]: any}[]}
   */
  query(sql, params) { /* no-op: generated stub */ }

  /**
   * The first row of query(sql, params), or null. 
   *
   * @param {string} sql - parameter
   * @param {any} params - parameter
   * @returns {{[key: string]: any}}
   */
  queryOne(sql, params) { /* no-op: generated stub */ }

  /**
   * The first column of the first row of query(sql, params), or null: queryValue('select count(*) from invoice where organization_id = :org', {}). 
   *
   * @param {string} sql - parameter
   * @param {any} params - parameter
   * @returns {any}
   */
  queryValue(sql, params) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class EntityField {
  constructor() {
  }

  /**
   *  
   *
   * @param {number} value - parameter
   * @returns {EntityField}
   */
  min(value) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {number} value - parameter
   * @returns {EntityField}
   */
  max(value) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} regex - parameter
   * @param {string} messageKey - parameter
   * @returns {EntityField}
   */
  pattern(regex, messageKey) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {function(*, Record<string, *>, ResultAndModel<Object, RuntimeServices>): (string|boolean|void)} fn - parameter
   * @returns {EntityField}
   */
  validate(fn) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {(string|number|boolean|function(ResultAndModel<Object, RuntimeServices>): (string|number|boolean|null))} value - parameter
   * @returns {EntityField}
   */
  defaultValue(value) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {(Array<string>|Record<string, string>|function(ResultAndModel<Object, RuntimeServices>): (Array<string>|Record<string, string>))} source - parameter
   * @returns {EntityField}
   */
  options(source) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {{read: string, write: string}} privileges - parameter
   * @returns {EntityField}
   */
  access(privileges) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {EntityField}
   */
  readOnly() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} key - parameter
   * @returns {EntityField}
   */
  label(key) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {number} length - parameter
   * @returns {EntityField}
   */
  maxLength(length) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} columnName - parameter
   * @returns {EntityField}
   */
  column(columnName) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {EntityField}
   */
  required() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {EntityField}
   */
  email() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} fieldName - parameter
   * @returns {EntityField}
   */
  mappedBy(fieldName) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} fieldName - parameter
   * @returns {EntityField}
   */
  displayField(fieldName) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {function(Record<string, *>, ResultAndModel<Object, RuntimeServices>): boolean} fn - parameter
   * @returns {EntityField}
   */
  visibleWhen(fn) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {function(Record<string, *>, ResultAndModel<Object, RuntimeServices>): boolean} fn - parameter
   * @returns {EntityField}
   */
  readOnlyWhen(fn) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} thisSide - parameter
   * @param {string} otherSide - parameter
   * @returns {EntityField}
   */
  joinColumns(thisSide, otherSide) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} hint - parameter
   * @returns {EntityField}
   */
  uiHint(hint) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} key - parameter
   * @returns {EntityField}
   */
  uiGroup(key) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} joinTable - parameter
   * @returns {EntityField}
   */
  through(joinTable) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class EntityBuilder {
  constructor() {
  }

  /**
   *  
   *
   * @param {function(Record<string, *>, ResultAndModel<Object, RuntimeServices>): (string|Record<string, string>|boolean|void)} fn - parameter
   * @returns {EntityBuilder}
   */
  validate(fn) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} name - parameter
   * @returns {EntityField}
   */
  field(name) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} name - parameter
   * @returns {EntityField}
   */
  file(name) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} name - parameter
   * @returns {EntityField}
   */
  time(name) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} tableName - parameter
   * @returns {EntityBuilder}
   */
  table(tableName) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {{read: string, write: string}} privileges - parameter
   * @returns {EntityBuilder}
   */
  access(privileges) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} name - parameter
   * @returns {EntityField}
   */
  text(name) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} name - parameter
   * @returns {EntityField}
   */
  files(name) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} name - parameter
   * @returns {EntityField}
   */
  date(name) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} name - parameter
   * @returns {EntityField}
   */
  decimal(name) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} name - parameter
   * @returns {EntityField}
   */
  integer(name) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} name - parameter
   * @param {string[]} values - parameter
   * @returns {EntityField}
   */
  choice(name, values) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} name - parameter
   * @returns {EntityField}
   */
  dateTime(name) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} operation - parameter
   * @param {Flow} flow - parameter
   * @returns {RouteHandle}
   */
  onChange(operation, flow) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} name - parameter
   * @returns {EntityField}
   */
  bigInteger(name) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {EntityField}
   */
  organization() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} fieldName - parameter
   * @returns {EntityBuilder}
   */
  displayField(fieldName) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {EntityBuilder}
   */
  versioned() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} url - parameter
   * @returns {CrudRegistrationHandle}
   */
  registerHtml(url) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {CrudRegistrationHandle}
   */
  registerApi() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} name - parameter
   * @param {string} entityKey - parameter
   * @returns {EntityField}
   */
  manyToOne(name, entityKey) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} name - parameter
   * @param {string} entityKey - parameter
   * @returns {EntityField}
   */
  oneToMany(name, entityKey) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} name - parameter
   * @param {string} entityKey - parameter
   * @returns {EntityField}
   */
  manyToMany(name, entityKey) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @returns {EntityBuilder}
   */
  audited() { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} name - parameter
   * @returns {EntityField}
   */
  longText(name) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {{read: string, write: string}} formulas - parameter
   * @returns {EntityBuilder}
   */
  rowAccess(formulas) { /* no-op: generated stub */ }

  /**
   *  
   *
   * @param {string} name - parameter
   * @returns {EntityField}
   */
  bool(name) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class RouteHandle {
  constructor() {
  }

  /**
   * For a job(): seconds one attempt may run (default 300). A longer one is stopped and counts as a failed attempt. 
   *
   * @param {number} seconds - parameter
   * @returns {RouteHandle}
   */
  timeout(seconds) { /* no-op: generated stub */ }

  /**
   * Who may reach this route: 'PUBLIC' (anonymous), 'GLOBAL' (any logged-in user), 'ORGANIZATION' (a member of the organization in the URL) or 'INTERNAL'. Defaults to 'GLOBAL'. An anonymous POST (a webhook) goes under /api/public/… with 'PUBLIC': no CSRF token, no session, the body untouched — check the sender's signature in the flow. A route under /api/public/ that is not PUBLIC fails the load; a PUBLIC POST elsewhere still needs a CSRF token. 
   *
   * @param {string} accessLevel - parameter
   * @returns {RouteHandle}
   */
  access(accessLevel) { /* no-op: generated stub */ }

  /**
   * Relative order among observers of the same event. Lower runs first. 
   *
   * @param {number} ordinal - parameter
   * @returns {RouteHandle}
   */
  order(ordinal) { /* no-op: generated stub */ }

  /**
   * For a job(): how many times to try again after a failed attempt, with a growing pause between them (default 4). Then the job is FAILED and the APPLICATION event JOB_FAILED is emitted. 
   *
   * @param {number} retries - parameter
   * @returns {RouteHandle}
   */
  retries(retries) { /* no-op: generated stub */ }

  /**
   * Let pages of other sites call this route from the browser (CORS): '*' for any site, or an origin / a list of origins, e.g. ['https://acme.com', 'https://www.acme.com']. The browser's OPTIONS preflight is answered for you and the answers carry Access-Control-Allow-Origin; cookies are never sent. Only on routes under /api/public/ (anonymous endpoints, .access('PUBLIC')). 
   *
   * @param {string|string[]} origins - parameter
   * @returns {RouteHandle}
   */
  cors(origins) { /* no-op: generated stub */ }

  /**
   * Privilege the caller must hold, e.g. 'canManageTodo'. Checked by the web layer before the flow runs; without it the request is refused. 
   *
   * @param {string} privilege - parameter
   * @returns {RouteHandle}
   */
  privilege(privilege) { /* no-op: generated stub */ }

  /**
   * Describe this route in the instance's OpenAPI descriptor (GET /api/v1/openapi.json): an OpenAPI 3.1 Operation object, e.g. {summary: 'Monthly report', tags: ['reports'], parameters: [...], requestBody: {...}, responses: {200: {description: 'OK', content: {'application/json': {schema: {...}}}}}}. Merged over what the route already says (method, path, path parameters, security, privilege). Only routes with openApi(...) are listed. 
   *
   * @param {Object} operation - parameter
   * @returns {RouteHandle}
   */
  openApi(operation) { /* no-op: generated stub */ }

  /**
   * Run the flow in one transaction: if it throws, every write it made is rolled back. On a web route or a cron, the whole flow is one transaction. On an entity change (entity.onChange(...).transactional()) the flow runs inside the transaction that saves the record, before it commits, and a throw rolls the save back; without it, change handlers run after the commit, asynchronously. Mind slow calls (integrations.*): the transaction holds a database connection while they wait. 
   *
   * @returns {RouteHandle}
   */
  transactional() { /* no-op: generated stub */ }

  /**
   * Watch the request without answering it. The response is left to the route that responds, so several observers may share one URL. 
   *
   * @returns {RouteHandle}
   */
  observer() { /* no-op: generated stub */ }

}

/**
 * @class
 */
class EventRouterApi {
  constructor() {
  }

  /**
   * Answer HTTP GET at this URL with the given flow. The pattern may capture path variables, e.g. '/html/organization/{organizationId}/todo/{id}'. 
   *
   * @param {string} urlPattern - parameter
   * @param {Flow} flow - parameter
   * @returns {RouteHandle}
   */
  get(urlPattern, flow) { /* no-op: generated stub */ }

  /**
   * Answer HTTP PUT at this URL with the given flow. The pattern may capture path variables, e.g. '/html/organization/{organizationId}/todo/{id}'. 
   *
   * @param {string} urlPattern - parameter
   * @param {Flow} flow - parameter
   * @returns {RouteHandle}
   */
  put(urlPattern, flow) { /* no-op: generated stub */ }

  /**
   * React to a non-web event: 'ENTITY_CHANGE', 'APPLICATION' or 'CUSTOM'. Always an observer — only a web request has a caller waiting for an answer. 
   *
   * @param {string} eventType - parameter
   * @param {string} eventName - parameter
   * @param {Flow} flow - parameter
   * @returns {RouteHandle}
   */
  on(eventType, eventName, flow) { /* no-op: generated stub */ }

  /**
   * Answer HTTP DELETE at this URL with the given flow. The pattern may capture path variables, e.g. '/html/organization/{organizationId}/todo/{id}'. 
   *
   * @param {string} urlPattern - parameter
   * @param {Flow} flow - parameter
   * @returns {RouteHandle}
   */
  delete(urlPattern, flow) { /* no-op: generated stub */ }

  /**
   * Answer HTTP PATCH at this URL with the given flow. The pattern may capture path variables, e.g. '/html/organization/{organizationId}/todo/{id}'. 
   *
   * @param {string} urlPattern - parameter
   * @param {Flow} flow - parameter
   * @returns {RouteHandle}
   */
  patch(urlPattern, flow) { /* no-op: generated stub */ }

  /**
   * Answer HTTP POST at this URL with the given flow. The pattern may capture path variables, e.g. '/html/organization/{organizationId}/todo/{id}'. 
   *
   * @param {string} urlPattern - parameter
   * @param {Flow} flow - parameter
   * @returns {RouteHandle}
   */
  post(urlPattern, flow) { /* no-op: generated stub */ }

  /**
   * Run a flow on a schedule. Spring six-field cron: second minute hour day month weekday, e.g. '0 0 5 * * *' for 05:00 daily. The jobs are cancelled and re-created on every reload, so an edited or deleted schedule leaves nothing ticking. 
   *
   * @param {string} cronExpression - parameter
   * @param {Flow} flow - parameter
   * @returns {RouteHandle}
   */
  cron(cronExpression, flow) { /* no-op: generated stub */ }

  /**
   * Declare a background job: the flow runs each time code calls services.jobs.enqueue(name, payload) — later, on a worker, as the user who queued it, in that organization. It is stored, so it survives a restart; a throw is retried with a growing pause (.retries(n), default 4), then the job is FAILED and JOB_FAILED is emitted. In the flow: a.event.payload(), a.event.attempt(), a.event.jobId(). One flow per name. 
   *
   * @param {string} name - parameter
   * @param {Flow} flow - parameter
   * @returns {RouteHandle}
   */
  job(name, flow) { /* no-op: generated stub */ }

  /**
   * Sugar for the commonest case: onEntityChange('todoTask', 'CREATED', flow), the same as todoTask.onChange('CREATED', flow) on the entity. Operation is CREATED, MODIFIED (or UPDATED) or DELETED. The handler runs after the save commits, asynchronously; add .transactional() to run it inside the save's transaction, where a throw rolls the save back. 
   *
   * @param {string} entityKey - parameter
   * @param {string} operation - parameter
   * @param {Flow} flow - parameter
   * @returns {RouteHandle}
   */
  onEntityChange(entityKey, operation, flow) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class CrudRegistrationHandle {
  constructor() {
  }

  /**
   * The sidebar section to list this CRUD in, e.g. menuGroup('Library'). Without one the CRUD is in no sidebar section and is reached by its URL or from the app's own pages. The section links to its alphabetically first list (by entity key); every list in it shows the others as tabs. Who sees it is still decided by the entity's read privilege. 
   *
   * @param {string} group - parameter
   * @returns {CrudRegistrationHandle}
   */
  menuGroup(group) { /* no-op: generated stub */ }

  /**
   * The list's label in its sidebar section's tabs and on its pages, instead of the entity key, e.g. menuLabel('Books'). 
   *
   * @param {string} label - parameter
   * @returns {CrudRegistrationHandle}
   */
  menuLabel(label) { /* no-op: generated stub */ }

  /**
   * Field names shown as columns of the generic table, in order. Pass them as arguments or as one array; empty means every field. 
   *
   * @param {any[]} fieldNames - parameter
   * @returns {CrudRegistrationHandle}
   */
  tableColumns(fieldNames) { /* no-op: generated stub */ }

  /**
   * Field names offered as table filters. 
   *
   * @param {any[]} fieldNames - parameter
   * @returns {CrudRegistrationHandle}
   */
  filterColumns(fieldNames) { /* no-op: generated stub */ }

  /**
   * A web-resource view to render the table with, instead of the built-in one. 
   *
   * @param {string} view - parameter
   * @returns {CrudRegistrationHandle}
   */
  tableView(view) { /* no-op: generated stub */ }

  /**
   * Adds a button to each row of the generic table, before delete, e.g. rowAction({icon: 'fa-link', label: 'invoice.action.portal', href: '/html/organization/{organizationId}/portal/invoice/{id}'}). Give exactly one of href (a link: a path, or an http(s) URL) or post (a path; submits a form with the CSRF token, for a route declared with eventRouter.post). {id} is the row's id and {organizationId} the list's organization (the button is hidden on a list without one). icon is a Font Awesome class ('fa-link', or 'fa-regular fa-envelope'). label (the tooltip) and confirm (asked before the action runs) are message keys, shown as written when no message has that key. privilege: only users holding it see the button (the route must still check it). newTab: open href in a new tab. Call it once per button; they appear in call order. 
   *
   * @param {{icon: string, label: string, href: (string|undefined), post: (string|undefined), confirm: (string|undefined), privilege: (string|undefined), newTab: (boolean|undefined)}} action - parameter
   * @returns {CrudRegistrationHandle}
   */
  rowAction(action) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class CrudConfigurationApi {
  constructor() {
  }

  /**
   * Serve an entity's HTML CRUD at the given URL (the same as entity.registerHtml(url)). Only the shapes the generic controllers are mapped at work: '/html/{obj}' or '/html/organization/{organizationId}/{obj}'; anything else fails the load. Registering '/html/note' generates: GET /html/note/all (the list), GET+POST /html/note/new/settings (create), GET+POST /html/note/{id}/settings (edit), POST /html/note/{id}/remove (delete), GET /html/note/{id}/view (read-only) and GET /html/note/schema. Link to those from a template, or respond with a redirect to one. 
   *
   * @param {string} url - parameter
   * @param {(EntityBuilder|string)} entity - parameter
   * @returns {CrudRegistrationHandle}
   */
  registerHtml(url, entity) { /* no-op: generated stub */ }

  /**
   * Serve an entity's JSON CRUD API, at its name — no URL to give. For entity 'note': GET /api/v1/entity/note (list; query note_page, note_size, note_sort=field,ASC|DESC, note_search, note_filter_<field>), POST /api/v1/entity/note (create), GET|PUT|DELETE /api/v1/entity/note/{id}, GET /api/v1/entity/note/schema; and the same under /api/v1/organization/{organizationId}/entity/note. Called with an API key (Authorization: Bearer pat_…). The whole API is described in GET /api/v1/openapi.json. 
   *
   * @param {(EntityBuilder|string)} entity - parameter
   * @returns {CrudRegistrationHandle}
   */
  registerApi(entity) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class SequenceBuilder {
  constructor() {
  }

  /**
   * When counting starts again: 'NEVER' (the default), 'YEARLY', 'MONTHLY' or 'DAILY'. The format must then contain that period's date parts, or it would give the same numbers again. 
   *
   * @param {string} reset - parameter
   * @returns {SequenceBuilder}
   */
  reset(reset) { /* no-op: generated stub */ }

  /**
   * How a number is written: {yyyy} {yy} {MM} {dd} for its date and one {0000} for the counter, padded to that many digits — 'INV-{yyyy}-{0000}' gives INV-2026-0042. Defaults to the bare counter. 
   *
   * @param {string} pattern - parameter
   * @returns {SequenceBuilder}
   */
  format(pattern) { /* no-op: generated stub */ }

  /**
   * One counter for the whole instance, instead of one per organization. 
   *
   * @returns {SequenceBuilder}
   */
  global() { /* no-op: generated stub */ }

  /**
   * The first number of each period. Defaults to 1. 
   *
   * @param {number} start - parameter
   * @returns {SequenceBuilder}
   */
  startAt(start) { /* no-op: generated stub */ }

}

/**
 * @class
 */
class BusinessCalendarBuilder {
  constructor() {
  }

  /**
   * The days off every week, e.g. .weekend('FRIDAY', 'SATURDAY'). Defaults to Saturday and Sunday; .weekend() with nothing makes every day of the week a working day. 
   *
   * @param {any[]} days - parameter
   * @returns {BusinessCalendarBuilder}
   */
  weekend(days) { /* no-op: generated stub */ }

  /**
   * Days off on one date each, as 'yyyy-MM-dd': .holidays('2026-05-04', '2026-12-31'). 
   *
   * @param {any[]} dates - parameter
   * @returns {BusinessCalendarBuilder}
   */
  holidays(dates) { /* no-op: generated stub */ }

  /**
   * Days off counted from (Western) Easter Sunday: 0 Easter Sunday, 1 Easter Monday, -2 Good Friday, 39 Ascension, 49 Pentecost, 60 Corpus Christi — .easter(1, 60). 
   *
   * @param {any[]} offsets - parameter
   * @returns {BusinessCalendarBuilder}
   */
  easter(offsets) { /* no-op: generated stub */ }

  /**
   * Days off on the same date every year, as 'MM-dd': .everyYear('01-01', '12-25'). 
   *
   * @param {any[]} monthDays - parameter
   * @returns {BusinessCalendarBuilder}
   */
  everyYear(monthDays) { /* no-op: generated stub */ }

}

/**
 * @class
 * @property {CrudConfigurationApi} crudConfiguration - Serves an entity's generic CRUD: registerHtml(url, entity) (pages) and registerApi(entity) (the JSON API at /api/v1/entity/<name>) — the same as entity.registerHtml(url) / entity.registerApi(). Declare at the top level of a unit.
 * @property {EventRouterApi} eventRouter - Routes the program's flows: get/post/put/patch/delete for web requests, cron, on(eventType, eventName, flow) and onEntityChange(entityKey, operation, flow) (the same as entity.onChange(operation, flow)). Declare at the top level of a unit.
 */
class SystemApi {
  constructor() {
    /** @type {CrudConfigurationApi} - Serves an entity's generic CRUD: registerHtml(url, entity) (pages) and registerApi(entity) (the JSON API at /api/v1/entity/<name>) — the same as entity.registerHtml(url) / entity.registerApi(). Declare at the top level of a unit. */
    this.crudConfiguration = null;

    /** @type {EventRouterApi} - Routes the program's flows: get/post/put/patch/delete for web requests, cron, on(eventType, eventName, flow) and onEntityChange(entityKey, operation, flow) (the same as entity.onChange(operation, flow)). Declare at the top level of a unit. */
    this.eventRouter = null;

  }

  /**
   * A logger with the given name (as context.services.system.getLogger(name)). 
   *
   * @param {string} name - parameter
   * @returns {ServiceLogger}
   */
  getLogger(name) { /* no-op: generated stub */ }

  /**
   * The dynamic-code logger (the same one context.services.system.getLogger() returns). 
   *
   * @returns {ServiceLogger}
   */
  getLogger() { /* no-op: generated stub */ }

  /**
   * The instance's public address, e.g. 'https://crm.example.com' (no trailing slash): build every absolute link with it — in emails, PDFs, webhooks, redirects to the outside — never with a hard-coded host. Also on context.services.system. 
   *
   * @returns {string}
   */
  getBaseUrl() { /* no-op: generated stub */ }

  /**
   * An entity over an existing table, named by its entity key (the table is its snake_case unless .table(...) says otherwise): let note = system.newEntity('note'); note.text('title').required(). Only in code/entity units, at the top level. 
   *
   * @param {string} name - parameter
   * @returns {EntityBuilder}
   */
  newEntity(name) { /* no-op: generated stub */ }

  /**
   * A new flow to chain steps onto: system.newFlow().thenSet('x', a => ...).respond(a => a.response.html('/view')). Steps read the request from their argument a. 
   *
   * @returns {Flow<any, any, RuntimeServices>}
   */
  newFlow() { /* no-op: generated stub */ }

  /**
   * A numbering sequence, e.g. invoice numbers: system.newSequence('invoice').format('INV-{yyyy}-{0000}').reset('YEARLY'). Take numbers with context.services.sequences.next('invoice'). Counters are per organization unless .global(). Declare at the top level of any unit. 
   *
   * @param {string} name - parameter
   * @returns {SequenceBuilder}
   */
  newSequence(name) { /* no-op: generated stub */ }

  /**
   * A business calendar for context.services.util.addBusinessDays / isBusinessDay: system.newBusinessCalendar('pl').everyYear('01-01', '05-03', '12-25').easter(1, 60).holidays('2026-05-04'). Saturday and Sunday are off unless .weekend(...) says otherwise. A calendar named 'default' is the one used when a call names none. Declare at the top level of any unit. 
   *
   * @param {string} name - parameter
   * @returns {BusinessCalendarBuilder}
   */
  newBusinessCalendar(name) { /* no-op: generated stub */ }

}

/** @type {SystemApi} */ var system;
/** @type {ResultAndModel<Object, RuntimeServices>} */ var context;
