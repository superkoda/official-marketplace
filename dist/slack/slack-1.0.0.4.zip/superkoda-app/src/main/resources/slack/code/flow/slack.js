import {system, context} from './superkoda';

// Routes behind the Slack settings page. All are per organization and need canManageSlack in it,
// except the OAuth callback, which Slack calls and which is authenticated by the signed state.
const base = '/api/v1/organization/{organizationId}/slack';
const body = a => {
    const t = a.web.request.getBodyText();
    return t ? a.services.util.parseJSON(t) : {};
};
const orgId = a => a.organization.getId();

let status = system.newFlow()
    .respond(a => a.response.json({
        configured: slackService.isConfigured(),
        redirectUri: slackService.redirectUri(a.web.request),
        isLocal: slackService.isLocal(a.web.request),
        connection: slackService.getConnection(orgId(a))
    }));
system.eventRouter.get(base + '/status', status)
    .access('ORGANIZATION').privilege('canManageSlack')
    .openApi({summary: 'Slack connection status of the organization', tags: ['slack']});

let connect = system.newFlow()
    .respond(a => {
        if (!slackService.isConfigured()) return a.response.json({error: 'not_configured'});
        // state = hostname + '.' + a dot-free random part
        const state = slackService.signState(orgId(a), a.user.getId(), slackService.hostname(a.web.request));
        return a.response.json({url: slackService.authorizeUrl(slackService.redirectUri(a.web.request), state)});
    });
system.eventRouter.post(base + '/connect', connect)
    .access('ORGANIZATION').privilege('canManageSlack')
    .openApi({summary: 'Start Slack OAuth; returns the Slack consent URL', tags: ['slack']});

let callback = system.newFlow()
    .respond(a => {
        const p = a.web.requestParameters;
        const st = slackService.isConfigured() ? slackService.verifyState(p.getAsText('state')) : null;
        if (st == null) return a.response.redirect('/');
        const back = '/html/organization/' + st.orgId + '/slack?slack=';
        if (p.getAsText('error')) return a.response.redirect(back + 'denied');
        const r = slackService.completeOAuth(st.orgId, st.userId, p.getAsText('code'),
            slackService.redirectUri(a.web.request));
        return a.response.redirect(back + (r.ok ? 'connected' : 'error&detail=' + a.services.util.encodeURI(r.error)));
    });
system.eventRouter.get('/api/v1/slack/oauth/callback', callback).access('PUBLIC');

let disconnect = system.newFlow()
    .respond(a => a.response.json(slackService.disconnect(orgId(a))));
system.eventRouter.post(base + '/disconnect', disconnect)
    .access('ORGANIZATION').privilege('canManageSlack')
    .openApi({summary: 'Disconnect the Slack workspace', tags: ['slack']});

let channels = system.newFlow()
    .respond(a => a.response.json({channels: slackService.listChannels(orgId(a))}));
system.eventRouter.get(base + '/channels', channels)
    .access('ORGANIZATION').privilege('canManageSlack')
    .openApi({summary: 'Channels the bot can see', tags: ['slack']});

let defaultChannel = system.newFlow()
    .respond(a => {
        const b = body(a);
        return a.response.json(slackService.setDefaultChannel(orgId(a), b.channelId, b.channelName));
    });
system.eventRouter.post(base + '/default-channel', defaultChannel)
    .access('ORGANIZATION').privilege('canManageSlack')
    .openApi({summary: 'Set the default channel', tags: ['slack']});

let test = system.newFlow()
    .respond(a => a.response.json(slackService.postMessage(orgId(a), {
        channel: body(a).channelId || null, // falls back to the default channel
        text: ':white_check_mark: Test message from superkoda, sent by ' + a.user.getName() + '.'
    })));
system.eventRouter.post(base + '/test', test)
    .access('ORGANIZATION').privilege('canManageSlack')
    .openApi({summary: 'Post a test message to the chosen channel (default channel if none)', tags: ['slack']});
