import {system, context} from './superkoda';

// One Slack workspace per organization. Deliberately NOT registerApi()'d: it holds the bot token,
// which only slackService may read; pages get a token-free view from the slack flows.
let slackConnection = system.newEntity('slackConnection')
    .displayField('teamName')
    .access({read: 'canManageSlack', write: 'canManageSlack'});
slackConnection.text('status').required();
slackConnection.text('statusDetail');
slackConnection.text('teamId');
slackConnection.text('teamName');
slackConnection.text('enterpriseId');
slackConnection.text('botUserId');
slackConnection.longText('botToken');
slackConnection.longText('scopes');
slackConnection.text('defaultChannelId');
slackConnection.text('defaultChannelName');
slackConnection.bigInteger('connectedBy');
slackConnection.audited();
