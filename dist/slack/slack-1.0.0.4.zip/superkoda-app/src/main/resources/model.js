/**
 * @class
 * @augments SuperkodaEntity
 * @property {string} fullName - 
 * @property {string} email - 
 * @property {string} organizationName - 
 * @property {string} message - 
 * @property {string} appName - 
 * @property {any} receivedAt - 
 * @property {string} status - 
 * @property {string} token - 
 * @property {string} requestType - 
 */
class DemoRequest {
  constructor() {
    /** @type {number} */ this.id = null;
    /** @type {number} */ this.organizationId = null;
    /** @type {string} */ this.fullName = null;
    /** @type {string} */ this.email = null;
    /** @type {string} */ this.organizationName = null;
    /** @type {string} */ this.message = null;
    /** @type {string} */ this.appName = null;
    /** @type {any} */ this.receivedAt = null;
    /** @type {string} */ this.status = null;
    /** @type {string} */ this.token = null;
    /** @type {string} */ this.requestType = null;
  }
}

/**
 * @class
 * @augments SuperkodaEntity
 * @property {string} fullName - 
 * @property {string} email - 
 * @property {string} organizationName - 
 * @property {string} message - 
 * @property {string} appName - 
 * @property {any} receivedAt - 
 * @property {string} status - 
 * @property {string} token - 
 */
class FormSubmission {
  constructor() {
    /** @type {number} */ this.id = null;
    /** @type {number} */ this.organizationId = null;
    /** @type {string} */ this.fullName = null;
    /** @type {string} */ this.email = null;
    /** @type {string} */ this.organizationName = null;
    /** @type {string} */ this.message = null;
    /** @type {string} */ this.appName = null;
    /** @type {any} */ this.receivedAt = null;
    /** @type {string} */ this.status = null;
    /** @type {string} */ this.token = null;
  }
}

/**
 * @class
 * @augments SuperkodaEntity
 * @property {string} code - 
 * @property {string} status - 
 * @property {any} expirationDate - 
 * @property {string} firstName - 
 * @property {string} lastName - 
 * @property {string} email - 
 * @property {string} organizationName - 
 */
class Voucher {
  constructor() {
    /** @type {number} */ this.id = null;
    /** @type {number} */ this.organizationId = null;
    /** @type {string} */ this.code = null;
    /** @type {string} */ this.status = null;
    /** @type {any} */ this.expirationDate = null;
    /** @type {string} */ this.firstName = null;
    /** @type {string} */ this.lastName = null;
    /** @type {string} */ this.email = null;
    /** @type {string} */ this.organizationName = null;
  }
}

/**
 * @class
 * @augments SuperkodaEntity
 * @property {string} status - 
 * @property {string} statusDetail - 
 * @property {string} teamId - 
 * @property {string} teamName - 
 * @property {string} enterpriseId - 
 * @property {string} botUserId - 
 * @property {string} botToken - 
 * @property {string} scopes - 
 * @property {string} defaultChannelId - 
 * @property {string} defaultChannelName - 
 * @property {number} connectedBy - 
 */
class SlackConnection {
  constructor() {
    /** @type {number} */ this.id = null;
    /** @type {number} */ this.organizationId = null;
    /** @type {string} */ this.status = null;
    /** @type {string} */ this.statusDetail = null;
    /** @type {string} */ this.teamId = null;
    /** @type {string} */ this.teamName = null;
    /** @type {string} */ this.enterpriseId = null;
    /** @type {string} */ this.botUserId = null;
    /** @type {string} */ this.botToken = null;
    /** @type {string} */ this.scopes = null;
    /** @type {string} */ this.defaultChannelId = null;
    /** @type {string} */ this.defaultChannelName = null;
    /** @type {number} */ this.connectedBy = null;
  }
}

/**
 * @class
 * @augments SuperkodaEntity
 * @property {string} email - 
 * @property {string} appName - 
 * @property {any} receivedAt - 
 */
class NotifyRequest {
  constructor() {
    /** @type {number} */ this.id = null;
    /** @type {number} */ this.organizationId = null;
    /** @type {string} */ this.email = null;
    /** @type {string} */ this.appName = null;
    /** @type {any} */ this.receivedAt = null;
  }
}

/**
 * @class
 */
class DataServicesProxy {
  /** @param {string} key @param {Object} toCache @param {number} organizationId @returns {Object} */ cachePut(key, toCache, organizationId) {}
  /** @param {string} key @param {number} organizationId @returns {Object} */ cacheGet(key, organizationId) {}
  /** @param {function(): Object} flowCode @returns {Object} */ runInTransaction(flowCode) {}
  /** Hand-written SQL, read-only; needs canManageBackend or the system. @returns {QueryExecutor} */ getQueryExecutor() {}
  /** @param {SecurityScope} [securityScope] - defaults to ALL @returns {ScopedSecureRepository<DemoRequest>} */ getDemoRequestRepository(securityScope) {}
  /** @param {SecurityScope} [securityScope] - defaults to ALL @returns {ScopedSecureRepository<FormSubmission>} */ getFormSubmissionRepository(securityScope) {}
  /** @param {SecurityScope} [securityScope] - defaults to ALL @returns {ScopedSecureRepository<Voucher>} */ getVoucherRepository(securityScope) {}
  /** @param {SecurityScope} [securityScope] - defaults to ALL @returns {ScopedSecureRepository<SlackConnection>} */ getSlackConnectionRepository(securityScope) {}
  /** @param {SecurityScope} [securityScope] - defaults to ALL @returns {ScopedSecureRepository<NotifyRequest>} */ getNotifyRequestRepository(securityScope) {}
}

/**
 * @readonly
 * @enum {string}
 */
const EntityKey = {
   demoRequest: 'demoRequest',
   formSubmission: 'formSubmission',
   voucher: 'voucher',
   slackConnection: 'slackConnection',
   notifyRequest: 'notifyRequest',
 }
/** @typedef {typeof EntityKey} EntityKeys */
