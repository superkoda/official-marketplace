// slackService: the Slack integration for every module. One workspace per organization.
//
//   slackService.postMessage(orgId, {text, blocks?, channel?, threadTs?})   -> {ok, channel, ts} | {ok:false, error}
//   slackService.postToDefaultChannel(orgId, text, blocks?)
//   slackService.postToUserByEmail(orgId, email, text, blocks?)
//   slackService.updateMessage(orgId, channel, ts, {text, blocks?})
//   slackService.deleteMessage(orgId, channel, ts)
//   slackService.lookupUserByEmail(orgId, email)  -> slack user id | null
//   slackService.listChannels(orgId)              -> [{id, name, isPrivate, isMember}]
//   slackService.isConnected(orgId)               -> boolean
//   slackService.getConnection(orgId)             -> token-free view | null
//
// Never throws on Slack errors: returns {ok:false, error}. A token_revoked / account_inactive /
// invalid_auth answer flips the connection to 'reauth_required'.
// Runs inside a request, job or event (uses context.services).
let slackService = {
    SLACK_API: 'https://slack.com/api/',
    // notify scopes + channelPicker (channels:read, groups:read) + chat:write.public (post to channels the bot is not in)
    SCOPES: 'chat:write,chat:write.public,im:write,users:read,users:read.email,channels:read,groups:read',
    REAUTH_ERRORS: ['token_revoked', 'account_inactive', 'invalid_auth', 'not_authed'],

    _svc: () => context.services,
    _repo: () => context.services.data.getSlackConnectionRepository(),

    _findEntity: orgId => {
        const rows = slackService._repo().search((root, query, cb) => cb.equal(root.get('organizationId'), orgId));
        return rows.length ? rows[0] : null;
    },

    // Token-free view, safe to return to a page.
    _view: c => c == null ? null : {
        status: c.getStatus(),
        statusDetail: c.getStatusDetail(),
        teamId: c.getTeamId(),
        teamName: c.getTeamName(),
        botUserId: c.getBotUserId(),
        defaultChannelId: c.getDefaultChannelId(),
        defaultChannelName: c.getDefaultChannelName()
    },

    getConnection: orgId => slackService._view(slackService._findEntity(orgId)),

    isConnected: orgId => {
        const c = slackService._findEntity(orgId);
        return c != null && c.getStatus() === 'active' && !!c.getBotToken();
    },

    // --- operator settings (instance-wide secrets: SLACK_CLIENT_ID, SLACK_CLIENT_SECRET) ---
    clientId: () => context.services.system.getSecret('SLACK_CLIENT_ID'),
    clientSecret: () => context.services.system.getSecret('SLACK_CLIENT_SECRET'),
    isConfigured: () => !!(slackService.clientId() && slackService.clientSecret()),

    // The OAuth redirect URL registered in the Slack app: one central callback for all instances. It tells the
    // instance apart by the hostname that leads the 'state' (see signState).
    CALLBACK_PATH: '/api/v1/slack/oauth/callback',
    REDIRECT_URI: 'https://auth.superkoda.com/api/v1/slack/oauth/callback',
    // The base URL the browser used (scheme + host), e.g. https://anton.sandbox.superkoda.com
    baseUrl: request => {
        const proto = request.getHeader('X-Forwarded-Proto');
        const fwd = request.getHeader('X-Forwarded-Host');
        if (fwd) return (proto ? String(proto).split(',')[0].trim() : 'https') + '://' + String(fwd).split(',')[0].trim();
        const m = String(request.getRequestURL()).match(/^(https?:\/\/[^\/]+)/);
        return m ? m[1] : '';
    },
    isLocal: request => /^(localhost|127\.\d+\.\d+\.\d+|\[?::1\]?|.*\.localhost)$/.test(slackService.hostname(request)),
    redirectUri: request => slackService.baseUrl(request) + slackService.CALLBACK_PATH,

    // Hostname this instance is served on (the one the browser used).
    hostname: request => {
        const fwd = request.getHeader('X-Forwarded-Host');
        if (fwd) return String(fwd).split(',')[0].trim().replace(/:\d+$/, '');
        const m = String(request.getRequestURL()).match(/^https?:\/\/([^\/:]+)/);
        return m ? m[1] : '';
    },

    // --- OAuth ---
    // state = hostname.orgId-userId-expiresAtMs-nonce-hmac(client secret): the leading hostname routes the
    // central callback back to this instance; the random part after it (letters, digits and '-' only, no dots)
    // ties the callback to the org and the admin (e.g. host.132-10000-1792166923083-lxRlwM4oTdo-50a3cb01...).
    _alnum: s => String(s).replace(/[^A-Za-z0-9]/g, ''),
    _sig: body => slackService._alnum(context.services.util.hmacSha256(slackService.clientSecret(), body)),
    signState: (orgId, userId, hostname) => {
        const body = orgId + '-' + userId + '-' + (Date.now() + 10 * 60 * 1000) + '-' + slackService._alnum(context.services.util.randomToken(8));
        return hostname + '.' + body + '-' + slackService._sig(body);
    },
    verifyState: state => {
        if (!state) return null;
        // the random part is everything after the last dot (the hostname has dots itself)
        const parts = String(state).substring(String(state).lastIndexOf('.') + 1).split('-');
        if (parts.length !== 5) return null;
        const tail = parts;
        const body = tail.slice(0, 4).join('-'), sig = tail[4];
        if (!context.services.util.constantTimeEquals(slackService._sig(body), sig)) return null;
        if (Number(tail[2]) < Date.now()) return null;
        return {orgId: Number(tail[0]), userId: Number(tail[1])};
    },
    authorizeUrl: (redirectUri, state) =>
        'https://slack.com/oauth/v2/authorize?client_id=' + context.services.util.encodeURI(slackService.clientId())
        + '&scope=' + context.services.util.encodeURI(slackService.SCOPES)
        + '&redirect_uri=' + context.services.util.encodeURI(redirectUri)
        + '&state=' + context.services.util.encodeURI(state),

    // Exchanges the code and stores the connection for the org (replacing any previous one).
    completeOAuth: (orgId, userId, code, redirectUri) => {
        const util = context.services.util;
        const res = context.services.integrations.restPost(slackService.SLACK_API + 'oauth.v2.access',
            'client_id=' + util.encodeURI(slackService.clientId())
            + '&client_secret=' + util.encodeURI(slackService.clientSecret())
            + '&code=' + util.encodeURI(code)
            + '&redirect_uri=' + util.encodeURI(redirectUri),
            {'Content-Type': 'application/x-www-form-urlencoded'});
        if (!res || !res.ok) return {ok: false, error: (res && res.error) || 'oauth_failed'};
        const repo = slackService._repo();
        const c = slackService._findEntity(orgId) || repo.getNew();
        const sameTeam = c.getTeamId() === (res.team && res.team.id);
        c.setOrganizationId(orgId);
        c.setStatus('active');
        c.setStatusDetail(null);
        c.setTeamId(res.team ? res.team.id : null);
        c.setTeamName(res.team ? res.team.name : null);
        c.setEnterpriseId(res.enterprise ? res.enterprise.id : null);
        c.setBotUserId(res.bot_user_id);
        c.setBotToken(res.access_token);
        c.setScopes(res.scope);
        c.setConnectedBy(userId);
        if (!sameTeam) { c.setDefaultChannelId(null); c.setDefaultChannelName(null); }
        repo.saveOne(c);
        return {ok: true};
    },

    disconnect: orgId => {
        const c = slackService._findEntity(orgId);
        if (c == null) return {ok: true};
        if (c.getBotToken()) {
            slackService._call(c, 'auth.revoke', {}); // best effort
        }
        slackService._repo().deleteOne(c);
        return {ok: true};
    },

    setDefaultChannel: (orgId, channelId, channelName) => {
        const c = slackService._findEntity(orgId);
        if (c == null) return {ok: false, error: 'not_connected'};
        c.setDefaultChannelId(channelId || null);
        c.setDefaultChannelName(channelId ? (channelName || null) : null);
        slackService._repo().saveOne(c);
        return {ok: true};
    },

    // --- Slack Web API ---
    _markReauth: (c, error) => {
        c.setStatus('reauth_required');
        c.setStatusDetail(error);
        slackService._repo().saveOne(c);
    },

    // POST JSON method (chat.*, conversations.open, auth.revoke ...) with the org's bot token.
    _call: (c, method, body) => {
        let res;
        try {
            // form-encoded like the OAuth call (restPost mangles the JSON charset, Slack answers invalid_charset);
            // structured values (blocks) go as JSON strings, which Slack accepts in form fields
            const util = context.services.util;
            const form = Object.keys(body || {}).filter(k => body[k] != null)
                .map(k => util.encodeURI(k) + '=' + util.encodeURI(typeof body[k] === 'object' ? JSON.stringify(body[k]) : String(body[k])))
                .join('&');
            res = context.services.integrations.restPost(slackService.SLACK_API + method, form,
                {'Authorization': 'Bearer ' + c.getBotToken(), 'Content-Type': 'application/x-www-form-urlencoded'});
        } catch (e) {
            return {ok: false, error: 'request_failed', detail: String(e)};
        }
        if (res && res.ok) return res;
        const error = (res && res.error) || 'unknown_error';
        if (slackService.REAUTH_ERRORS.indexOf(error) >= 0 && method !== 'auth.revoke') slackService._markReauth(c, error);
        return {ok: false, error: error};
    },

    _get: (c, method, query) => {
        let res;
        try {
            res = context.services.integrations.restGet(slackService.SLACK_API + method + (query ? '?' + query : ''),
                {'Authorization': 'Bearer ' + c.getBotToken()});
        } catch (e) {
            return {ok: false, error: 'request_failed', detail: String(e)};
        }
        if (res && res.ok) return res;
        const error = (res && res.error) || 'unknown_error';
        if (slackService.REAUTH_ERRORS.indexOf(error) >= 0) slackService._markReauth(c, error);
        return {ok: false, error: error};
    },

    _active: orgId => {
        const c = slackService._findEntity(orgId);
        if (c == null || !c.getBotToken()) return {err: {ok: false, error: 'not_connected'}};
        if (c.getStatus() !== 'active') return {err: {ok: false, error: c.getStatus()}};
        return {c: c};
    },

    // opts: {text, blocks?, channel? (id; defaults to the org default channel), threadTs?}
    postMessage: (orgId, opts) => {
        const r = slackService._active(orgId);
        if (r.err) return r.err;
        const channel = opts.channel || r.c.getDefaultChannelId();
        if (!channel) return {ok: false, error: 'no_channel'};
        const body = {channel: channel, text: opts.text || ''};
        if (opts.blocks) body.blocks = opts.blocks;
        if (opts.threadTs) body.thread_ts = opts.threadTs;
        const res = slackService._call(r.c, 'chat.postMessage', body);
        return res.ok ? {ok: true, channel: res.channel, ts: res.ts} : res;
    },

    postToDefaultChannel: (orgId, text, blocks) => slackService.postMessage(orgId, {text: text, blocks: blocks}),

    updateMessage: (orgId, channel, ts, opts) => {
        const r = slackService._active(orgId);
        if (r.err) return r.err;
        const body = {channel: channel, ts: ts, text: opts.text || ''};
        if (opts.blocks) body.blocks = opts.blocks;
        const res = slackService._call(r.c, 'chat.update', body);
        return res.ok ? {ok: true, channel: res.channel, ts: res.ts} : res;
    },

    deleteMessage: (orgId, channel, ts) => {
        const r = slackService._active(orgId);
        if (r.err) return r.err;
        const res = slackService._call(r.c, 'chat.delete', {channel: channel, ts: ts});
        return res.ok ? {ok: true} : res;
    },

    lookupUserByEmail: (orgId, email) => {
        const r = slackService._active(orgId);
        if (r.err) return null;
        const res = slackService._get(r.c, 'users.lookupByEmail', 'email=' + context.services.util.encodeURI(email));
        return res.ok ? res.user.id : null;
    },

    // DM: posting to a user id opens the conversation automatically.
    postToUserByEmail: (orgId, email, text, blocks) => {
        const userId = slackService.lookupUserByEmail(orgId, email);
        if (!userId) return {ok: false, error: 'users_not_found'};
        return slackService.postMessage(orgId, {channel: userId, text: text, blocks: blocks});
    },

    listChannels: orgId => {
        const r = slackService._active(orgId);
        if (r.err) return [];
        const out = [];
        let cursor = '';
        for (let page = 0; page < 10; page++) {
            const res = slackService._get(r.c, 'conversations.list',
                'types=public_channel,private_channel&exclude_archived=true&limit=200'
                + (cursor ? '&cursor=' + context.services.util.encodeURI(cursor) : ''));
            if (!res.ok) break;
            for (const ch of res.channels) out.push({id: ch.id, name: ch.name, isPrivate: !!ch.is_private, isMember: !!ch.is_member});
            cursor = res.response_metadata && res.response_metadata.next_cursor;
            if (!cursor) break;
        }
        out.sort((x, y) => x.name < y.name ? -1 : x.name > y.name ? 1 : 0);
        return out;
    }
};
