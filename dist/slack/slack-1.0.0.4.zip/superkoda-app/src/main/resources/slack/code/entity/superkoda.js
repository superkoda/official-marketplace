import '../../../api.js';
import '../../../model.js';

/** @type {SystemApi} */
export const system = new SystemApi();
/** @type {ResultAndModel<Object, RuntimeServices>} */
export const context = new ResultAndModel();
