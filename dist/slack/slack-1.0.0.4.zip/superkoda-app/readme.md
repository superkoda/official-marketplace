# superkoda-slack

An exported superkoda **app module** — its components (forms, web-resources, flows, services,
privileges, files, …) live under `src/main/resources/`, in a folder named after the module:

```
src/main/resources/
  api.js                                     # JSDoc for the editor: the code API (not a component)
  model.js                                   # JSDoc for the editor: this instance's entities (not a component)
  <module>/
    code/entity/*.js                         # an entity: the file name is its name
    code/flow/*.js                           # a flow: routes and schedules are inside the code
    code/services/*.js                       # a service module
    code/migration/*.sql                     # schema migrations, if the package carries any
    components/<type>/*.yaml                 # descriptors for the types that need one
    templates/web-resource/**                # web-resource bodies
    file/**                                  # binary file payloads
```

**The folder is the module declaration.** A component's name comes from its file name and its module
from the folder, so forms, flows and services carry no descriptor at all — everything else they
express is inside the code. The types that do keep a descriptor keep it for metadata that has nowhere
else to live (a web resource's access level and type, a privilege's group), and none of them names its
module: the folder already did.

A package may contain several module folders side by side; an export of a single module contains one.

## Build the import package

```
mvn package
```

produces `target/superkoda-slack-1.0.0-superkoda-package.zip`. Upload it on a running
superkoda instance under **Admin → App Import / Export → Import** (or `POST /html/app-components/import`).

You can also import this project directory zipped as-is — the importer reads everything under
`src/main/resources/` and ignores whatever sits above it, including this project's own name.

## Notes

- A component package carries **definitions only**. The target instance must already have this module's
  database tables (created by its schema migrations, which are managed separately).
- Editing components: change the code file — or, for the types that have one, the YAML descriptor and
  the file it references — then rebuild.
- Renaming the module folder renames the module on the next import. That is the intended way to do it.
