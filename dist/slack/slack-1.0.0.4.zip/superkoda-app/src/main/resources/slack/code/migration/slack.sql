-- @module slack : 1.0.0.0
-- @init
-- create table slack_connection
CREATE SEQUENCE IF NOT EXISTS seqorganizationrelatedid START 120150 INCREMENT 10;
CREATE TABLE IF NOT EXISTS slack_connection (
  id bigint NOT NULL,
  created_by character varying(255),
  created_by_id bigint,
  created_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
  index_string character varying(16300) DEFAULT '',
  modified_by character varying(255),
  modified_by_id bigint,
  organization_id bigint NOT NULL,
  updated_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
  status character varying(255) DEFAULT 'active' NOT NULL,
  status_detail character varying(255),
  team_id character varying(255),
  team_name character varying(255),
  enterprise_id character varying(255),
  bot_user_id character varying(255),
  bot_token text,
  scopes text,
  default_channel_id character varying(255),
  default_channel_name character varying(255),
  connected_by bigint,
  PRIMARY KEY (id, organization_id),
  UNIQUE (id, organization_id),
  FOREIGN KEY (organization_id) REFERENCES organization(id) ON UPDATE CASCADE
);
ALTER TABLE slack_connection ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS slack_connection_org ON slack_connection;
CREATE POLICY slack_connection_org ON slack_connection FOR ALL USING (current_setting('superkoda.org_id', true) IS NULL OR current_setting('superkoda.org_id', true) = '' OR organization_id = (current_setting('superkoda.org_id', true)::bigint));
INSERT INTO dynamic_entity (id, table_name, created_on, updated_on) SELECT nextval('seqsystemid'), 'slack_connection', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP WHERE NOT EXISTS (SELECT 1 FROM dynamic_entity WHERE table_name = 'slack_connection');
UPDATE dynamic_entity SET module = 'slack' WHERE table_name = 'slack_connection' AND module IS NULL;

